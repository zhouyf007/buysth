package com.shop.seckill.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shop.common.exception.BizException;
import com.shop.common.result.PageResult;
import com.shop.seckill.dto.CouponForm;
import com.shop.seckill.dto.CouponValidateRequest;
import com.shop.seckill.dto.CouponValidateResponse;
import com.shop.seckill.dto.CouponVO;
import com.shop.seckill.entity.Coupon;
import com.shop.seckill.entity.UserCoupon;
import com.shop.seckill.mapper.CouponMapper;
import com.shop.seckill.mapper.UserCouponMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CouponService {

    private final CouponMapper couponMapper;
    private final UserCouponMapper userCouponMapper;

    public PageResult<CouponVO> listPublic(long current, long size, Long userId) {
        LocalDateTime now = LocalDateTime.now();
        Page<Coupon> page = couponMapper.selectPage(new Page<>(current, size),
                new LambdaQueryWrapper<Coupon>()
                        .eq(Coupon::getStatus, 1)
                        .le(Coupon::getStartTime, now)
                        .ge(Coupon::getEndTime, now)
                        .orderByDesc(Coupon::getCreateTime));
        List<Long> couponIds = page.getRecords().stream().map(Coupon::getId).collect(Collectors.toList());
        Map<Long, UserCoupon> received = userId == null || couponIds.isEmpty() ? Map.of()
                : userCouponMapper.selectList(new LambdaQueryWrapper<UserCoupon>()
                        .eq(UserCoupon::getUserId, userId)
                        .in(UserCoupon::getCouponId, couponIds))
                .stream().collect(Collectors.toMap(UserCoupon::getCouponId, Function.identity()));
        List<CouponVO> vos = page.getRecords().stream().map(c -> toVO(c, received.get(c.getId()))).collect(Collectors.toList());
        return PageResult.of(vos, page.getTotal(), page.getCurrent(), page.getSize());
    }

    @Transactional
    public void receive(Long userId, Long couponId) {
        Coupon coupon = couponMapper.selectById(couponId);
        LocalDateTime now = LocalDateTime.now();
        if (coupon == null || coupon.getStatus() == null || coupon.getStatus() != 1
                || now.isBefore(coupon.getStartTime()) || now.isAfter(coupon.getEndTime())) {
            throw new BizException("优惠券不在领取时间");
        }
        Long exist = userCouponMapper.selectCount(new LambdaQueryWrapper<UserCoupon>()
                .eq(UserCoupon::getUserId, userId)
                .eq(UserCoupon::getCouponId, couponId));
        if (exist != null && exist > 0) {
            throw new BizException("您已领取过该优惠券");
        }
        int updated = couponMapper.update(null, new LambdaUpdateWrapper<Coupon>()
                .eq(Coupon::getId, couponId)
                .apply("(total = 0 OR received_count < total)")
                .setSql("received_count = received_count + 1"));
        if (updated == 0) {
            throw new BizException("优惠券已被领完");
        }
        UserCoupon uc = new UserCoupon();
        uc.setUserId(userId);
        uc.setCouponId(couponId);
        uc.setStatus("UNUSED");
        uc.setReceiveTime(now);
        userCouponMapper.insert(uc);
    }

    public List<CouponVO> myCoupons(Long userId) {
        LocalDateTime now = LocalDateTime.now();
        List<UserCoupon> ucs = userCouponMapper.selectList(new LambdaQueryWrapper<UserCoupon>()
                .eq(UserCoupon::getUserId, userId)
                .orderByDesc(UserCoupon::getReceiveTime));
        Map<Long, Coupon> couponMap = ucs.isEmpty() ? Map.of()
                : couponMapper.selectBatchIds(ucs.stream().map(UserCoupon::getCouponId).collect(Collectors.toList()))
                .stream().collect(Collectors.toMap(Coupon::getId, Function.identity()));
        return ucs.stream().map(uc -> {
            CouponVO vo = toVO(couponMap.get(uc.getCouponId()), uc);
            vo.setUserCouponId(uc.getId());
            vo.setStatus(uc.getStatus());
            if ("UNUSED".equals(uc.getStatus()) && couponMap.get(uc.getCouponId()) != null
                    && now.isAfter(couponMap.get(uc.getCouponId()).getEndTime())) {
                vo.setStatus("EXPIRED");
            }
            return vo;
        }).collect(Collectors.toList());
    }

    public CouponValidateResponse validate(CouponValidateRequest request) {
        CouponValidateResponse response = new CouponValidateResponse();
        response.setValid(false);
        if (request.getCouponId() == null || request.getTotalAmount() == null) {
            response.setMessage("请选择优惠券");
            return response;
        }
        UserCoupon uc = userCouponMapper.selectOne(new LambdaQueryWrapper<UserCoupon>()
                .eq(UserCoupon::getUserId, request.getUserId())
                .eq(UserCoupon::getCouponId, request.getCouponId())
                .eq(UserCoupon::getStatus, "UNUSED"));
        Coupon coupon = couponMapper.selectById(request.getCouponId());
        LocalDateTime now = LocalDateTime.now();
        if (uc == null || coupon == null || coupon.getStatus() == null || coupon.getStatus() != 1
                || now.isBefore(coupon.getStartTime()) || now.isAfter(coupon.getEndTime())) {
            response.setMessage("优惠券不可用");
            return response;
        }
        BigDecimal discount = computeDiscount(coupon, request.getTotalAmount());
        if (discount == null) {
            response.setMessage("订单金额未达到使用门槛");
            return response;
        }
        response.setValid(true);
        response.setUserCouponId(uc.getId());
        response.setName(coupon.getName());
        response.setDiscountAmount(discount);
        return response;
    }

    @Transactional
    public void use(Long userCouponId, String orderNo) {
        UserCoupon uc = userCouponMapper.selectById(userCouponId);
        if (uc == null || !"UNUSED".equals(uc.getStatus())) {
            throw new BizException("优惠券不可用");
        }
        uc.setStatus("USED");
        uc.setOrderNo(orderNo);
        uc.setUseTime(LocalDateTime.now());
        userCouponMapper.updateById(uc);
    }

    public void revertByOrder(String orderNo) {
        userCouponMapper.update(null, new LambdaUpdateWrapper<UserCoupon>()
                .eq(UserCoupon::getOrderNo, orderNo)
                .eq(UserCoupon::getStatus, "USED")
                .set(UserCoupon::getStatus, "UNUSED")
                .set(UserCoupon::getOrderNo, null)
                .set(UserCoupon::getUseTime, null));
    }

    public PageResult<Coupon> adminPage(long current, long size, String keyword) {
        Page<Coupon> page = couponMapper.selectPage(new Page<>(current, size),
                new LambdaQueryWrapper<Coupon>()
                        .and(keyword != null && !keyword.isBlank(), w -> w.like(Coupon::getName, keyword))
                        .orderByDesc(Coupon::getCreateTime));
        return PageResult.of(page);
    }

    public void createCoupon(CouponForm form) {
        couponMapper.insert(applyForm(new Coupon(), form));
    }

    public void updateCoupon(Long id, CouponForm form) {
        Coupon coupon = couponMapper.selectById(id);
        if (coupon == null) {
            throw new BizException(404, "优惠券不存在");
        }
        couponMapper.updateById(applyForm(coupon, form));
    }

    public void deleteCoupon(Long id) {
        couponMapper.deleteById(id);
    }

    public void updateStatus(Long id, Integer status) {
        Coupon coupon = couponMapper.selectById(id);
        if (coupon == null) {
            throw new BizException(404, "优惠券不存在");
        }
        coupon.setStatus(status);
        couponMapper.updateById(coupon);
    }

    private Coupon applyForm(Coupon coupon, CouponForm form) {
        coupon.setName(form.getName());
        coupon.setType(form.getType());
        coupon.setThreshold(form.getThreshold() == null ? BigDecimal.ZERO : form.getThreshold());
        coupon.setDiscountValue(form.getDiscountValue());
        coupon.setTotal(form.getTotal() == null ? 0 : form.getTotal());
        coupon.setStartTime(form.getStartTime());
        coupon.setEndTime(form.getEndTime());
        coupon.setStatus(form.getStatus() == null ? 1 : form.getStatus());
        return coupon;
    }

    private BigDecimal computeDiscount(Coupon coupon, BigDecimal total) {
        if ("FIXED".equals(coupon.getType())) {
            if (total.compareTo(coupon.getThreshold()) < 0) {
                return null;
            }
            return coupon.getDiscountValue().min(total).setScale(2, RoundingMode.HALF_UP);
        }
        if ("PERCENT".equals(coupon.getType())) {
            return total.multiply(BigDecimal.ONE.subtract(
                    coupon.getDiscountValue().divide(BigDecimal.valueOf(100)))).setScale(2, RoundingMode.HALF_UP);
        }
        return BigDecimal.ZERO;
    }

    private CouponVO toVO(Coupon coupon, UserCoupon uc) {
        CouponVO vo = new CouponVO();
        if (coupon == null) {
            vo.setName("已失效优惠券");
            return vo;
        }
        vo.setId(coupon.getId());
        vo.setCouponId(coupon.getId());
        vo.setName(coupon.getName());
        vo.setType(coupon.getType());
        vo.setThreshold(coupon.getThreshold());
        vo.setDiscountValue(coupon.getDiscountValue());
        vo.setStartTime(coupon.getStartTime());
        vo.setEndTime(coupon.getEndTime());
        vo.setTotal(coupon.getTotal());
        vo.setReceivedCount(coupon.getReceivedCount());
        vo.setReceived(uc != null);
        if (uc != null) {
            vo.setUserCouponId(uc.getId());
            vo.setStatus(uc.getStatus());
        }
        return vo;
    }
}
