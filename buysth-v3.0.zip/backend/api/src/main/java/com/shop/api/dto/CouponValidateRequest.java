package com.shop.api.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CouponValidateRequest {

    private Long userId;
    private Long couponId;
    private BigDecimal totalAmount;
}

