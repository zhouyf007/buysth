package com.shop.api.feign;

import com.shop.api.dto.ProductDTO;
import com.shop.api.dto.SalesIncreaseRequest;
import com.shop.api.dto.SkuDTO;
import com.shop.api.dto.StockLockRequest;
import com.shop.common.result.Result;
import org.springframework.stereotype.Component;

@Component
public class ProductClientFallback implements ProductClient {

    @Override
    public Result<ProductDTO> getProduct(Long productId) {
        return Result.fail(503, "商品服务暂不可用");
    }

    @Override
    public Result<SkuDTO> getSku(Long skuId) {
        return Result.fail(503, "商品服务暂不可用");
    }

    @Override
    public Result<Boolean> lockStock(StockLockRequest request) {
        return Result.fail(503, "商品服务暂不可用");
    }

    @Override
    public Result<Boolean> releaseStock(StockLockRequest request) {
        return Result.fail(503, "商品服务暂不可用");
    }

    @Override
    public Result<Boolean> increaseSales(SalesIncreaseRequest request) {
        return Result.fail(503, "商品服务暂不可用");
    }
}
