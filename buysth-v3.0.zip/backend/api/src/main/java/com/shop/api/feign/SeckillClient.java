package com.shop.api.feign;

import com.shop.api.dto.PromotionDTO;
import com.shop.api.dto.CouponValidateRequest;
import com.shop.api.dto.CouponValidateResponse;
import com.shop.common.result.Result;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.Map;

@FeignClient(name = "seckill-service")
public interface SeckillClient {

    @GetMapping("/internal/promotions/{code}")
    Result<PromotionDTO> getPromotion(@PathVariable("code") String code);

    @PostMapping("/internal/coupons/validate")
    Result<CouponValidateResponse> validateCoupon(@RequestBody CouponValidateRequest request);

    @PostMapping("/internal/coupons/use")
    Result<Void> useCoupon(@RequestBody Map<String, Object> body);
}
