package com.shop.auth.config;

import com.shop.common.mq.MQConstants;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AuthMQConfig {

    @Bean
    public Queue authPaidQueue() {
        return new Queue(MQConstants.Q_AUTH_ORDER_PAID, true);
    }

    @Bean
    public Queue authRefundedQueue() {
        return new Queue(MQConstants.Q_AUTH_ORDER_REFUNDED, true);
    }

    @Bean
    public Binding authPaidBinding(TopicExchange topicExchange) {
        return BindingBuilder.bind(authPaidQueue())
                .to(topicExchange).with(MQConstants.KEY_ORDER_PAID);
    }

    @Bean
    public Binding authRefundedBinding(TopicExchange topicExchange) {
        return BindingBuilder.bind(authRefundedQueue())
                .to(topicExchange).with(MQConstants.KEY_ORDER_REFUNDED);
    }
}

