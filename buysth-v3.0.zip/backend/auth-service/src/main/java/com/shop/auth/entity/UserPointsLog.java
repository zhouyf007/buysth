package com.shop.auth.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.shop.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@TableName("user_points_log")
public class UserPointsLog extends BaseEntity {

    private Long userId;
    private Integer changePoints;
    private String reason;
    private String orderNo;
}

