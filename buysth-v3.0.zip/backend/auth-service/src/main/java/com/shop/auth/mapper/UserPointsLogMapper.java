package com.shop.auth.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop.auth.entity.UserPointsLog;

public interface UserPointsLogMapper extends BaseMapper<UserPointsLog> {
}

