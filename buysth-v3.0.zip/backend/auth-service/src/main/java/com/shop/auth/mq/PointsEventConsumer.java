package com.shop.auth.mq;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shop.auth.service.PointsService;
import com.shop.common.mq.MQConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class PointsEventConsumer {

    private final PointsService pointsService;
    private final ObjectMapper objectMapper;

    @RabbitListener(queues = MQConstants.Q_AUTH_ORDER_PAID)
    public void onPaid(String message) {
        try {
            pointsService.onOrderPaid(objectMapper.readValue(message, Map.class));
        } catch (Exception e) {
            log.error("handle paid points failed: {}", message, e);
        }
    }

    @RabbitListener(queues = MQConstants.Q_AUTH_ORDER_REFUNDED)
    public void onRefunded(String message) {
        try {
            pointsService.onOrderRefunded(objectMapper.readValue(message, Map.class));
        } catch (Exception e) {
            log.error("handle refunded points failed: {}", message, e);
        }
    }
}

