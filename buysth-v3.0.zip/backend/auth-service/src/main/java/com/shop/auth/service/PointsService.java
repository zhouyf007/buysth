package com.shop.auth.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shop.api.dto.OrderInfoDTO;
import com.shop.api.feign.OrderClient;
import com.shop.auth.entity.SysUser;
import com.shop.auth.entity.UserPointsLog;
import com.shop.auth.mapper.SysUserMapper;
import com.shop.auth.mapper.UserPointsLogMapper;
import com.shop.common.result.PageResult;
import com.shop.common.result.Result;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class PointsService {

    private final SysUserMapper userMapper;
    private final UserPointsLogMapper pointsLogMapper;
    private final OrderClient orderClient;

    @Transactional
    public void onOrderPaid(Map<String, Object> event) {
        String orderNo = String.valueOf(event.get("orderNo"));
        OrderInfoDTO order = getOrder(orderNo);
        if (order == null || order.getUserId() == null) {
            return;
        }
        int points = order.getPayAmount() == null ? 0 : order.getPayAmount().intValue();
        changePoints(order.getUserId(), points, "订单支付获得积分", orderNo);
    }

    @Transactional
    public void onOrderRefunded(Map<String, Object> event) {
        String orderNo = String.valueOf(event.get("orderNo"));
        OrderInfoDTO order = getOrder(orderNo);
        if (order == null || order.getUserId() == null) {
            return;
        }
        int points = order.getPayAmount() == null ? 0 : order.getPayAmount().intValue();
        changePoints(order.getUserId(), -points, "订单退款扣减积分", orderNo);
    }

    public PageResult<UserPointsLog> userPointsLog(Long userId, long current, long size) {
        Page<UserPointsLog> page = pointsLogMapper.selectPage(new Page<>(current, size),
                new LambdaQueryWrapper<UserPointsLog>()
                        .eq(UserPointsLog::getUserId, userId)
                        .orderByDesc(UserPointsLog::getCreateTime));
        return PageResult.of(page);
    }

    private void changePoints(Long userId, int delta, String reason, String orderNo) {
        SysUser user = userMapper.selectById(userId);
        if (user == null) {
            return;
        }
        int points = (user.getPoints() == null ? 0 : user.getPoints()) + delta;
        if (points < 0) {
            points = 0;
        }
        user.setPoints(points);
        user.setLevel(computeLevel(points));
        userMapper.updateById(user);

        UserPointsLog log = new UserPointsLog();
        log.setUserId(userId);
        log.setChangePoints(delta);
        log.setReason(reason);
        log.setOrderNo(orderNo);
        pointsLogMapper.insert(log);
    }

    private int computeLevel(int points) {
        if (points >= 50000) return 5;
        if (points >= 20000) return 4;
        if (points >= 5000) return 3;
        if (points >= 1000) return 2;
        return 1;
    }

    private OrderInfoDTO getOrder(String orderNo) {
        try {
            Result<OrderInfoDTO> result = orderClient.getByOrderNo(orderNo);
            return result.isSuccess() ? result.getData() : null;
        } catch (Exception e) {
            log.warn("get order failed for points, orderNo={}", orderNo, e);
            return null;
        }
    }
}

