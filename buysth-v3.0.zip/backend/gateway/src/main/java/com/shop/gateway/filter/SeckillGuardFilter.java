package com.shop.gateway.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shop.gateway.security.FnvHash;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
@RequiredArgsConstructor
public class SeckillGuardFilter implements GlobalFilter, Ordered {

    private final StringRedisTemplate redisTemplate;
    private final ObjectMapper objectMapper;

    @Value("${shop.gateway.sign-secret:shop-sign-secret-2026}")
    private String signSecret;

    @Value("${shop.gateway.seckill-user-limit:5}")
    private int userLimit;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String path = exchange.getRequest().getURI().getPath();
        HttpMethod method = exchange.getRequest().getMethod();
        if (!HttpMethod.POST.equals(method) || !path.matches("/api/seckill/\\d+/products/\\d+")) {
            return chain.filter(exchange);
        }

        String timestamp = exchange.getRequest().getHeaders().getFirst("X-Timestamp");
        String nonce = exchange.getRequest().getHeaders().getFirst("X-Nonce");
        String sign = exchange.getRequest().getHeaders().getFirst("X-Sign");
        if (timestamp == null || nonce == null || sign == null) {
            return writeError(exchange, HttpStatus.BAD_REQUEST, 400, "缺少秒杀签名参数");
        }
        try {
            long ts = Long.parseLong(timestamp);
            if (Math.abs(Instant.now().getEpochSecond() - ts) > 120) {
                return writeError(exchange, HttpStatus.BAD_REQUEST, 400, "秒杀请求时间戳已过期");
            }
        } catch (NumberFormatException e) {
            return writeError(exchange, HttpStatus.BAD_REQUEST, 400, "秒杀签名参数格式错误");
        }

        String expected = FnvHash.sha256Hex(signSecret + path + timestamp + nonce);
        if (!expected.equalsIgnoreCase(sign)) {
            return writeError(exchange, HttpStatus.FORBIDDEN, 403, "秒杀请求签名校验失败");
        }

        String nonceKey = "gateway:nonce:" + nonce;
        Boolean first = redisTemplate.opsForValue().setIfAbsent(nonceKey, "1", 5, TimeUnit.MINUTES);
        if (!Boolean.TRUE.equals(first)) {
            return writeError(exchange, HttpStatus.TOO_MANY_REQUESTS, 429, "秒杀请求重复提交");
        }

        String userId = exchange.getRequest().getHeaders().getFirst("X-User-Id");
        if (userId != null) {
            long minute = Instant.now().getEpochSecond() / 60;
            String limitKey = "gateway:seckill:limit:" + userId + ":" + minute;
            Long count = redisTemplate.opsForValue().increment(limitKey);
            if (count != null && count == 1) {
                redisTemplate.expire(limitKey, 60, TimeUnit.SECONDS);
            }
            if (count != null && count > userLimit) {
                return writeError(exchange, HttpStatus.TOO_MANY_REQUESTS, 429, "秒杀请求过于频繁，请稍后再试");
            }
        }
        return chain.filter(exchange);
    }

    private Mono<Void> writeError(ServerWebExchange exchange, HttpStatus status, int code, String message) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(status);
        response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
        try {
            String json = objectMapper.writeValueAsString(Map.of(
                    "code", code,
                    "message", message,
                    "data", (Object) null));
            DataBuffer buffer = response.bufferFactory().wrap(json.getBytes(StandardCharsets.UTF_8));
            return response.writeWith(Mono.just(buffer));
        } catch (Exception e) {
            return response.setComplete();
        }
    }

    @Override
    public int getOrder() {
        return -90;
    }
}
