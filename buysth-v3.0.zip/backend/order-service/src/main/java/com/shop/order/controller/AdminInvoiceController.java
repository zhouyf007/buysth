package com.shop.order.controller;

import com.shop.common.result.PageResult;
import com.shop.common.result.Result;
import com.shop.order.entity.Invoice;
import com.shop.order.service.InvoiceService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin/invoices")
@RequiredArgsConstructor
public class AdminInvoiceController {

    private final InvoiceService invoiceService;

    @GetMapping
    public Result<PageResult<Invoice>> page(@RequestParam(defaultValue = "1") long current,
                                            @RequestParam(defaultValue = "10") long size,
                                            @RequestParam(required = false) String status,
                                            @RequestParam(required = false) String keyword) {
        return Result.ok(invoiceService.adminPage(current, size, status, keyword));
    }

    @PostMapping("/{id}/issue")
    public Result<Void> issue(@PathVariable Long id) {
        invoiceService.issue(id);
        return Result.ok();
    }

    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        invoiceService.adminDelete(id);
        return Result.ok();
    }
}
