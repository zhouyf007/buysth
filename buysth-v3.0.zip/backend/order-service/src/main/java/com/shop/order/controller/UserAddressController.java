package com.shop.order.controller;

import com.shop.common.context.UserContext;
import com.shop.common.result.Result;
import com.shop.order.dto.AddressForm;
import com.shop.order.entity.UserAddress;
import com.shop.order.service.AddressService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/order/address")
@RequiredArgsConstructor
public class UserAddressController {

    private final AddressService addressService;

    @GetMapping
    public Result<List<UserAddress>> list() {
        return Result.ok(addressService.list(UserContext.getUserId()));
    }

    @PostMapping
    public Result<Void> save(@Valid @RequestBody AddressForm form) {
        addressService.save(UserContext.getUserId(), form);
        return Result.ok();
    }

    @PutMapping("/{id}")
    public Result<Void> update(@PathVariable Long id, @Valid @RequestBody AddressForm form) {
        addressService.update(UserContext.getUserId(), id, form);
        return Result.ok();
    }

    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        addressService.delete(UserContext.getUserId(), id);
        return Result.ok();
    }

    @PutMapping("/{id}/default")
    public Result<Void> setDefault(@PathVariable Long id) {
        addressService.setDefault(UserContext.getUserId(), id);
        return Result.ok();
    }
}

