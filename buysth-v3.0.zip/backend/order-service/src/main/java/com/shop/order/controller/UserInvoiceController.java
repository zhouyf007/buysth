package com.shop.order.controller;

import com.shop.common.context.UserContext;
import com.shop.common.result.PageResult;
import com.shop.common.result.Result;
import com.shop.order.dto.InvoiceForm;
import com.shop.order.entity.Invoice;
import com.shop.order.service.InvoiceService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/order/invoice")
@RequiredArgsConstructor
public class UserInvoiceController {

    private final InvoiceService invoiceService;

    @PostMapping
    public Result<Void> apply(@RequestBody Map<String, Object> body) {
        InvoiceForm form = new InvoiceForm();
        form.setType(body.get("type") == null ? "PERSONAL" : String.valueOf(body.get("type")));
        form.setTitle(body.get("title") == null ? null : String.valueOf(body.get("title")));
        form.setTaxNo(body.get("taxNo") == null ? null : String.valueOf(body.get("taxNo")));
        form.setEmail(body.get("email") == null ? null : String.valueOf(body.get("email")));
        invoiceService.apply(UserContext.getUserId(), String.valueOf(body.get("orderNo")), form);
        return Result.ok();
    }

    @GetMapping
    public Result<PageResult<Invoice>> list(@RequestParam(defaultValue = "1") long current,
                                            @RequestParam(defaultValue = "10") long size) {
        return Result.ok(invoiceService.userPage(UserContext.getUserId(), current, size));
    }
}

