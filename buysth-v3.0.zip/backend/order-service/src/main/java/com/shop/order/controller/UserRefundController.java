package com.shop.order.controller;

import com.shop.common.context.UserContext;
import com.shop.common.result.PageResult;
import com.shop.common.result.Result;
import com.shop.order.dto.RefundApplyRequest;
import com.shop.order.entity.OrderRefund;
import com.shop.order.service.RefundService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/order/refund")
@RequiredArgsConstructor
public class UserRefundController {

    private final RefundService refundService;

    @PostMapping
    public Result<OrderRefund> apply(@RequestBody RefundApplyRequest request) {
        return Result.ok(refundService.apply(UserContext.getUserId(), request.getOrderNo(), request.getReason()));
    }

    @GetMapping
    public Result<PageResult<OrderRefund>> list(@RequestParam(defaultValue = "1") long current,
                                                @RequestParam(defaultValue = "10") long size) {
        return Result.ok(refundService.userPage(UserContext.getUserId(), current, size));
    }
}

