package com.shop.order.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class AddressForm extends AddressDTO {

    private Integer isDefault;
}

