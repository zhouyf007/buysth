package com.shop.order.dto;

import lombok.Data;

@Data
public class InvoiceForm {

    private String type;
    private String title;
    private String taxNo;
    private String email;
}

