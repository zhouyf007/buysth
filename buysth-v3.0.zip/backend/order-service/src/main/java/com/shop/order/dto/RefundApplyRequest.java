package com.shop.order.dto;

import lombok.Data;

@Data
public class RefundApplyRequest {

    private String orderNo;
    private String reason;
}

