package com.shop.order.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.shop.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
@TableName("invoice")
public class Invoice extends BaseEntity {

    private String orderNo;
    private Long userId;
    private String type;
    private String title;
    private String taxNo;
    private String email;
    private String invoiceNo;
    private String status;
}

