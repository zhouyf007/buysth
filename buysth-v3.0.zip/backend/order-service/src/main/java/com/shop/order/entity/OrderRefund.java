package com.shop.order.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.shop.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = true)
@TableName("order_refund")
public class OrderRefund extends BaseEntity {

    private String refundNo;
    private String orderNo;
    private Long userId;
    private BigDecimal amount;
    private String reason;
    private String status;
    private LocalDateTime applyTime;
    private LocalDateTime auditTime;
    private String auditRemark;
}

