package com.shop.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop.order.entity.Invoice;

public interface InvoiceMapper extends BaseMapper<Invoice> {
}

