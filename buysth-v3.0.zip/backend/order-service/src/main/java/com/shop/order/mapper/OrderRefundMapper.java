package com.shop.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop.order.entity.OrderRefund;

public interface OrderRefundMapper extends BaseMapper<OrderRefund> {
}

