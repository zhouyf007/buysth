package com.shop.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop.order.entity.UserAddress;

public interface UserAddressMapper extends BaseMapper<UserAddress> {
}

