package com.shop.order.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.shop.common.exception.BizException;
import com.shop.order.dto.AddressForm;
import com.shop.order.entity.UserAddress;
import com.shop.order.mapper.UserAddressMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AddressService {

    private final UserAddressMapper addressMapper;

    public List<UserAddress> list(Long userId) {
        return addressMapper.selectList(new LambdaQueryWrapper<UserAddress>()
                .eq(UserAddress::getUserId, userId)
                .orderByDesc(UserAddress::getIsDefault)
                .orderByDesc(UserAddress::getCreateTime));
    }

    @Transactional
    public void save(Long userId, AddressForm form) {
        if (addressMapper.selectCount(new LambdaQueryWrapper<UserAddress>()
                .eq(UserAddress::getUserId, userId)) == 0) {
            form.setIsDefault(1);
        }
        UserAddress address = new UserAddress();
        address.setUserId(userId);
        apply(address, form);
        if (address.getIsDefault() != null && address.getIsDefault() == 1) {
            clearDefault(userId);
        }
        addressMapper.insert(address);
    }

    @Transactional
    public void update(Long userId, Long id, AddressForm form) {
        UserAddress address = getOwned(userId, id);
        apply(address, form);
        if (address.getIsDefault() != null && address.getIsDefault() == 1) {
            clearDefault(userId);
        }
        addressMapper.updateById(address);
    }

    public void delete(Long userId, Long id) {
        UserAddress address = getOwned(userId, id);
        addressMapper.deleteById(address.getId());
    }

    @Transactional
    public void setDefault(Long userId, Long id) {
        UserAddress address = getOwned(userId, id);
        clearDefault(userId);
        address.setIsDefault(1);
        addressMapper.updateById(address);
    }

    private void apply(UserAddress address, AddressForm form) {
        address.setReceiverName(form.getReceiverName());
        address.setReceiverPhone(form.getReceiverPhone());
        address.setReceiverAddress(form.getReceiverAddress());
        address.setIsDefault(form.getIsDefault() == null ? 0 : form.getIsDefault());
    }

    private UserAddress getOwned(Long userId, Long id) {
        UserAddress address = addressMapper.selectById(id);
        if (address == null || !address.getUserId().equals(userId)) {
            throw new BizException(404, "地址不存在");
        }
        return address;
    }

    private void clearDefault(Long userId) {
        addressMapper.update(null, new LambdaUpdateWrapper<UserAddress>()
                .eq(UserAddress::getUserId, userId)
                .set(UserAddress::getIsDefault, 0));
    }
}

