package com.shop.order.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.shop.common.exception.BizException;
import com.shop.common.result.PageResult;
import com.shop.common.util.OrderNoGenerator;
import com.shop.order.dto.InvoiceForm;
import com.shop.order.entity.Invoice;
import com.shop.order.entity.Orders;
import com.shop.order.mapper.InvoiceMapper;
import com.shop.order.mapper.OrdersMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class InvoiceService {

    private final InvoiceMapper invoiceMapper;
    private final OrdersMapper ordersMapper;

    public void apply(Long userId, String orderNo, InvoiceForm form) {
        Orders order = ordersMapper.selectOne(new LambdaQueryWrapper<Orders>()
                .eq(Orders::getOrderNo, orderNo)
                .eq(Orders::getAdminDeleted, 0));
        if (order == null || !order.getUserId().equals(userId)) {
            throw new BizException(404, "订单不存在");
        }
        if (!"PAID".equals(order.getStatus()) && !"SHIPPED".equals(order.getStatus())
                && !"COMPLETED".equals(order.getStatus())) {
            throw new BizException("当前订单状态不可申请发票");
        }
        Long exist = invoiceMapper.selectCount(new LambdaQueryWrapper<Invoice>().eq(Invoice::getOrderNo, orderNo));
        if (exist != null && exist > 0) {
            throw new BizException("该订单已申请过发票");
        }
        Invoice invoice = new Invoice();
        invoice.setOrderNo(orderNo);
        invoice.setUserId(userId);
        invoice.setType(form.getType() == null ? "PERSONAL" : form.getType());
        invoice.setTitle(form.getTitle());
        invoice.setTaxNo(form.getTaxNo());
        invoice.setEmail(form.getEmail());
        invoice.setStatus("PENDING");
        invoiceMapper.insert(invoice);
    }

    public PageResult<Invoice> userPage(Long userId, long current, long size) {
        Page<Invoice> page = invoiceMapper.selectPage(new Page<>(current, size),
                new LambdaQueryWrapper<Invoice>()
                        .eq(Invoice::getUserId, userId)
                        .orderByDesc(Invoice::getCreateTime));
        return PageResult.of(page);
    }

    public PageResult<Invoice> adminPage(long current, long size, String status, String keyword) {
        Page<Invoice> page = invoiceMapper.selectPage(new Page<>(current, size),
                new LambdaQueryWrapper<Invoice>()
                        .eq(StringUtils.hasText(status), Invoice::getStatus, status)
                        .and(StringUtils.hasText(keyword), w -> w.like(Invoice::getOrderNo, keyword)
                                .or().like(Invoice::getInvoiceNo, keyword))
                        .orderByDesc(Invoice::getCreateTime));
        return PageResult.of(page);
    }

    public void issue(Long id) {
        Invoice invoice = invoiceMapper.selectById(id);
        if (invoice == null) {
            throw new BizException(404, "发票申请不存在");
        }
        invoice.setStatus("ISSUED");
        invoice.setInvoiceNo("INV" + OrderNoGenerator.generate(""));
        invoiceMapper.updateById(invoice);
    }

    public void adminDelete(Long id) {
        if (invoiceMapper.selectById(id) == null) {
            throw new BizException(404, "发票申请不存在");
        }
        invoiceMapper.deleteById(id);
    }
}
