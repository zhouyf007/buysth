package com.shop.order.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shop.common.exception.BizException;
import com.shop.common.mq.MQConstants;
import com.shop.common.result.PageResult;
import com.shop.common.util.OrderNoGenerator;
import com.shop.order.entity.OrderItem;
import com.shop.order.entity.OrderRefund;
import com.shop.order.entity.Orders;
import com.shop.order.mapper.OrderItemMapper;
import com.shop.order.mapper.OrderRefundMapper;
import com.shop.order.mapper.OrdersMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class RefundService {

    private final OrderRefundMapper refundMapper;
    private final OrdersMapper ordersMapper;
    private final OrderItemMapper orderItemMapper;
    private final RabbitTemplate rabbitTemplate;
    private final ObjectMapper objectMapper;

    @Transactional
    public OrderRefund apply(Long userId, String orderNo, String reason) {
        Orders order = ordersMapper.selectOne(new LambdaQueryWrapper<Orders>()
                .eq(Orders::getOrderNo, orderNo)
                .eq(Orders::getAdminDeleted, 0));
        if (order == null || !order.getUserId().equals(userId)) {
            throw new BizException(404, "订单不存在");
        }
        if (!List.of("PAID", "SHIPPED", "COMPLETED").contains(order.getStatus())) {
            throw new BizException("当前订单状态不可申请退款");
        }
        Long pending = refundMapper.selectCount(new LambdaQueryWrapper<OrderRefund>()
                .eq(OrderRefund::getOrderNo, orderNo)
                .eq(OrderRefund::getStatus, "PENDING"));
        if (pending != null && pending > 0) {
            throw new BizException("该订单已有退款申请处理中");
        }
        OrderRefund refund = new OrderRefund();
        refund.setRefundNo(OrderNoGenerator.generate("R"));
        refund.setOrderNo(orderNo);
        refund.setUserId(userId);
        refund.setAmount(order.getPayAmount());
        refund.setReason(reason);
        refund.setStatus("PENDING");
        refund.setApplyTime(LocalDateTime.now());
        refundMapper.insert(refund);
        return refund;
    }

    public PageResult<OrderRefund> userPage(Long userId, long current, long size) {
        Page<OrderRefund> page = refundMapper.selectPage(new Page<>(current, size),
                new LambdaQueryWrapper<OrderRefund>()
                        .eq(OrderRefund::getUserId, userId)
                        .orderByDesc(OrderRefund::getApplyTime));
        return PageResult.of(page);
    }

    public PageResult<OrderRefund> adminPage(long current, long size, String status, String keyword) {
        Page<OrderRefund> page = refundMapper.selectPage(new Page<>(current, size),
                new LambdaQueryWrapper<OrderRefund>()
                        .eq(StringUtils.hasText(status), OrderRefund::getStatus, status)
                        .and(StringUtils.hasText(keyword), w -> w.like(OrderRefund::getOrderNo, keyword)
                                .or().like(OrderRefund::getRefundNo, keyword))
                        .orderByDesc(OrderRefund::getApplyTime));
        return PageResult.of(page);
    }

    public void adminDelete(Long id) {
        if (refundMapper.selectById(id) == null) {
            throw new BizException(404, "退款申请不存在");
        }
        refundMapper.deleteById(id);
    }

    @Transactional
    public void audit(Long refundId, boolean approve, String remark, String operator) {
        OrderRefund refund = refundMapper.selectById(refundId);
        if (refund == null || !"PENDING".equals(refund.getStatus())) {
            throw new BizException("退款申请不存在或已处理");
        }
        refund.setAuditTime(LocalDateTime.now());
        refund.setAuditRemark(remark);
        if (approve) {
            refund.setStatus("REFUNDED");
            refundMapper.updateById(refund);
            Orders order = ordersMapper.selectOne(new LambdaQueryWrapper<Orders>()
                    .eq(Orders::getOrderNo, refund.getOrderNo())
                    .eq(Orders::getAdminDeleted, 0));
            if (order != null) {
                order.setStatus("REFUNDED");
                ordersMapper.updateById(order);
            }
            publishRefunded(refund);
        } else {
            refund.setStatus("REJECTED");
            refundMapper.updateById(refund);
        }
    }

    private void publishRefunded(OrderRefund refund) {
        try {
            List<OrderItem> items = orderItemMapper.selectList(new LambdaQueryWrapper<OrderItem>()
                    .eq(OrderItem::getOrderNo, refund.getOrderNo()));
            List<Map<String, Object>> lines = items.stream().map(item -> {
                Map<String, Object> line = new HashMap<>();
                line.put("skuId", item.getSkuId());
                line.put("quantity", item.getQuantity());
                return line;
            }).collect(Collectors.toList());
            Map<String, Object> event = new HashMap<>();
            event.put("type", "ORDER_REFUNDED");
            event.put("orderNo", refund.getOrderNo());
            event.put("refundNo", refund.getRefundNo());
            event.put("items", lines);
            rabbitTemplate.convertAndSend(MQConstants.TOPIC_EXCHANGE, MQConstants.KEY_ORDER_REFUNDED,
                    objectMapper.writeValueAsString(event));
        } catch (Exception e) {
            log.error("publish refunded event failed, refundNo={}", refund.getRefundNo(), e);
        }
    }
}
