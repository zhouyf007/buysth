package com.shop.seckill.config;

import com.shop.common.mq.MQConstants;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CouponMQConfig {

    @Bean
    public Queue seckillRefundedQueue() {
        return new Queue(MQConstants.Q_SECKILL_ORDER_REFUNDED, true);
    }

    @Bean
    public Binding seckillRefundedBinding(TopicExchange topicExchange) {
        return BindingBuilder.bind(seckillRefundedQueue())
                .to(topicExchange).with(MQConstants.KEY_ORDER_REFUNDED);
    }
}

