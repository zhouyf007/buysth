package com.shop.seckill.controller;

import com.shop.common.cache.RedisCache;
import com.shop.common.result.Result;
import com.shop.common.util.OrderNoGenerator;
import com.shop.seckill.dto.CaptchaVO;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.ThreadLocalRandom;

@RestController
@RequestMapping("/api/seckill")
@RequiredArgsConstructor
public class CaptchaController {

    private final RedisCache redisCache;

    @GetMapping("/captcha")
    public Result<CaptchaVO> captcha() {
        int a = ThreadLocalRandom.current().nextInt(1, 10);
        int b = ThreadLocalRandom.current().nextInt(1, 10);
        String captchaId = "C" + OrderNoGenerator.generate("");
        CaptchaVO vo = new CaptchaVO();
        vo.setCaptchaId(captchaId);
        vo.setQuestion(a + " + " + b + " = ?");
        redisCache.set("seckill:captcha:" + captchaId, String.valueOf(a + b), 120);
        return Result.ok(vo);
    }
}

