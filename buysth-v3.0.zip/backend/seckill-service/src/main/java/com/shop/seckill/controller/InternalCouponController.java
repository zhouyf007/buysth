package com.shop.seckill.controller;

import com.shop.common.result.Result;
import com.shop.seckill.dto.CouponValidateRequest;
import com.shop.seckill.dto.CouponValidateResponse;
import com.shop.seckill.service.CouponService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/internal/coupons")
@RequiredArgsConstructor
public class InternalCouponController {

    private final CouponService couponService;

    @PostMapping("/validate")
    public Result<CouponValidateResponse> validate(@RequestBody CouponValidateRequest request) {
        return Result.ok(couponService.validate(request));
    }

    @PostMapping("/use")
    public Result<Void> use(@RequestBody Map<String, Object> body) {
        couponService.use(Long.valueOf(String.valueOf(body.get("userCouponId"))),
                String.valueOf(body.get("orderNo")));
        return Result.ok();
    }
}

