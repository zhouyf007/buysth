package com.shop.seckill.controller;

import com.shop.common.context.UserContext;
import com.shop.common.result.PageResult;
import com.shop.common.result.Result;
import com.shop.seckill.dto.CouponVO;
import com.shop.seckill.service.CouponService;
import lombok.RequiredArgsConstructor;
import com.shop.common.context.UserContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/seckill/coupons")
@RequiredArgsConstructor
public class UserCouponController {

    private final CouponService couponService;

    @GetMapping
    public Result<PageResult<CouponVO>> list(@RequestParam(defaultValue = "1") long current,
                                             @RequestParam(defaultValue = "10") long size) {
        return Result.ok(couponService.listPublic(current, size, UserContext.getUserId()));
    }

    @GetMapping("/my")
    public Result<List<CouponVO>> my() {
        return Result.ok(couponService.myCoupons(UserContext.getUserId()));
    }

    @PostMapping("/{id}/receive")
    public Result<Void> receive(@PathVariable Long id) {
        couponService.receive(UserContext.getUserId(), id);
        return Result.ok();
    }
}
