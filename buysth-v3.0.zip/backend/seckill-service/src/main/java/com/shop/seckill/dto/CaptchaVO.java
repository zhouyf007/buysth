package com.shop.seckill.dto;

import lombok.Data;

@Data
public class CaptchaVO {

    private String captchaId;
    private String question;
}

