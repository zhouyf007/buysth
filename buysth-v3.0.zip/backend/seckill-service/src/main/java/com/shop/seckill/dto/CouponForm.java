package com.shop.seckill.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class CouponForm {

    @NotBlank(message = "优惠券名称不能为空")
    private String name;

    @NotBlank(message = "优惠券类型不能为空")
    private String type;

    private BigDecimal threshold;
    private BigDecimal discountValue;
    private Integer total;
    private LocalDateTime startTime;

    private LocalDateTime endTime;
    private Integer status;
}
