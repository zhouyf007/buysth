package com.shop.seckill.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class CouponVO {

    private Long id;
    private Long couponId;
    private Long userCouponId;
    private String name;
    private String type;
    private BigDecimal threshold;
    private BigDecimal discountValue;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private Integer total;
    private Integer receivedCount;
    private String status;
    private Boolean received;
}
