package com.shop.seckill.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CouponValidateRequest {

    private Long userId;
    private Long couponId;
    private BigDecimal totalAmount;
}

