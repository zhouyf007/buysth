package com.shop.seckill.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CouponValidateResponse {

    private boolean valid;
    private String message;
    private Long userCouponId;
    private String name;
    private BigDecimal discountAmount;
}

