package com.shop.seckill.dto;

import lombok.Data;

@Data
public class SeckillBuyRequest {

    private String captchaId;
    private String captchaAnswer;
}

