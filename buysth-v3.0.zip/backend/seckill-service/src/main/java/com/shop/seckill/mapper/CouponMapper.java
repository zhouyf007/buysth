package com.shop.seckill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop.seckill.entity.Coupon;

public interface CouponMapper extends BaseMapper<Coupon> {
}

