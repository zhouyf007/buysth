package com.shop.seckill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.shop.seckill.entity.UserCoupon;

public interface UserCouponMapper extends BaseMapper<UserCoupon> {
}

