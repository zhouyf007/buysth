package com.shop.seckill.mq;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.shop.common.mq.MQConstants;
import com.shop.seckill.service.CouponService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.util.Map;

@Slf4j
@Component
@RequiredArgsConstructor
public class CouponEventConsumer {

    private final CouponService couponService;
    private final ObjectMapper objectMapper;

    @RabbitListener(queues = MQConstants.Q_SECKILL_ORDER_REFUNDED)
    public void onRefunded(String message) {
        try {
            Map<String, Object> event = objectMapper.readValue(message, Map.class);
            couponService.revertByOrder(String.valueOf(event.get("orderNo")));
        } catch (Exception e) {
            log.error("handle refunded coupon failed: {}", message, e);
        }
    }
}

