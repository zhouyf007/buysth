@echo off
cd /d D:\buysth\frontend\admin-web
"D:\Program Files\nodejs\npm.cmd" run dev > "D:\buysth\deploy\logs\admin-web.log" 2> "D:\buysth\deploy\logs\admin-web.err.log"
