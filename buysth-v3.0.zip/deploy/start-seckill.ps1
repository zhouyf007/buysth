param(
    [switch]$SkipBuild
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path $PSScriptRoot -Parent
$EnvFile = Join-Path $PSScriptRoot '.env-shop'
$LogDir = Join-Path $PSScriptRoot 'logs'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null

if (Test-Path $EnvFile) {
    Get-Content $EnvFile | ForEach-Object {
        if ($_ -match '^([^#=]+)=(.*)$') {
            [Environment]::SetEnvironmentVariable($matches[1].Trim(), $matches[2].Trim(), 'Process')
        }
    }
}

$jar = Join-Path $Root 'backend\seckill-service\target\seckill-service-1.0.0.jar'
if (-not (Test-Path $jar)) {
    throw "Jar not found: $jar"
}

$javaExe = (Get-Command java -ErrorAction SilentlyContinue).Source
if (-not $javaExe) {
    $javaExe = 'C:\Program Files\Java\jdk-17\bin\java.exe'
}
$out = Join-Path $LogDir 'seckill-service.log'
$err = Join-Path $LogDir 'seckill-service.err.log'
$oldPath = $env:Path
Remove-Item Env:Path -ErrorAction SilentlyContinue
try {
    $proc = Start-Process -FilePath $javaExe -ArgumentList '-jar', $jar -WorkingDirectory $Root `
        -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err -PassThru
} finally {
    $env:Path = $oldPath
}
$proc.Id | Set-Content (Join-Path $PSScriptRoot '.seckill.pid')
Write-Host "seckill-service started pid $($proc.Id)"
