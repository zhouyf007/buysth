﻿$ErrorActionPreference = 'Continue'
$base = 'http://localhost:8080'
$pass = 0
$fail = 0

function CallApi($m, $p, $token = '', $body = $null) {
    $headers = @{}
    if ($token) { $headers.Authorization = "Bearer $token" }
    $params = @{ Method = $m; Uri = "$base$p"; Headers = $headers; UseBasicParsing = $true }
    if ($null -ne $body) {
        $params.ContentType = 'application/json; charset=utf-8'
        $params.Body = [System.Text.Encoding]::UTF8.GetBytes(($body | ConvertTo-Json -Depth 8))
    }
    $resp = Invoke-WebRequest @params
    $obj = ([System.Text.Encoding]::UTF8.GetString($resp.RawContentStream.ToArray()) | ConvertFrom-Json)
    if ($obj.code -ne 0) { throw "API $m $p failed: $($obj.message)" }
    return $obj.data
}

function Check($name, $ok) {
    if ($ok) { $script:pass++; Write-Host "  [PASS] $name" -ForegroundColor Green }
    else { $script:fail++; Write-Host "  [FAIL] $name" -ForegroundColor Red }
}

function CountOf($list, $field, $value) {
    return @(@($list) | Where-Object { $_.$field -eq $value }).Count
}

Write-Host '===== 交易闭环专项验收 =====' -ForegroundColor Magenta
$user = CallApi 'POST' '/api/auth/login' '' @{username='user'; password='123456'}
$ut = $user.accessToken
$admin = CallApi 'POST' '/api/auth/login' '' @{username='admin'; password='123456'}
$at = $admin.accessToken

# 1. 地址簿
CallApi 'POST' '/api/order/address' $ut @{receiverName='张三';receiverPhone='13812345678';receiverAddress='南京市测试路1号';isDefault=1} | Out-Null
$addrList = CallApi 'GET' '/api/order/address' $ut
$addrId = @($addrList)[0].id
Check '地址簿新增' (CountOf $addrList 'receiverName' '张三' -gt 0)
CallApi 'PUT' "/api/order/address/$addrId" $ut @{receiverName='张三丰';receiverPhone='13812345678';receiverAddress='南京市测试路2号';isDefault=1} | Out-Null
$addrList2 = CallApi 'GET' '/api/order/address' $ut
Check '地址簿修改' (CountOf $addrList2 'receiverName' '张三丰' -gt 0)

# 2. 优惠券
$start = (Get-Date).AddDays(-1).ToString('yyyy-MM-ddTHH:mm:ss')
$end = (Get-Date).AddDays(30).ToString('yyyy-MM-ddTHH:mm:ss')
$couponForm = @{name='满100减10测试券';type='FIXED';threshold=100;discountValue=10;total=100;startTime=$start;endTime=$end;status=1}
CallApi 'POST' '/api/admin/coupons' $at $couponForm | Out-Null
$coupons = CallApi 'GET' '/api/seckill/coupons?current=1&size=50'
$couponId = @($coupons.records | Where-Object { $_.name -eq '满100减10测试券' })[0].id
Check '优惠券发布可见' ($couponId -gt 0)
CallApi 'POST' "/api/seckill/coupons/$couponId/receive" $ut | Out-Null
$myCoupons = CallApi 'GET' '/api/seckill/coupons/my' $ut
Check '优惠券领取' (CountOf $myCoupons 'couponId' $couponId -gt 0)
$dup = $false
try { CallApi 'POST' "/api/seckill/coupons/$couponId/receive" $ut | Out-Null } catch { $dup = $true }
Check '优惠券不可重复领取' $dup

# 3. 优惠券下单
$order = CallApi 'POST' '/api/order/create' $ut @{
    items = @(@{skuId=201;quantity=1})
    address = @{receiverName='张三丰';receiverPhone='13812345678';receiverAddress='南京市测试路2号'}
    couponId = $couponId
}
$orderDetail = CallApi 'GET' "/api/order/$($order.orderNo)" $ut
Check '优惠券下单立减' ($orderDetail.discountAmount -ge 10)
$myCoupons2 = CallApi 'GET' '/api/seckill/coupons/my' $ut
$used = @($myCoupons2 | Where-Object { $_.couponId -eq $couponId })[0]
Check '优惠券核销' ($used.status -eq 'USED')

# 4. 支付后积分
$pointsBefore = (CallApi 'GET' '/api/auth/me' $ut).points
$pay = CallApi 'POST' '/api/pay/create' $ut @{orderNo=$order.orderNo}
CallApi 'POST' "/api/pay/mock/notify/$($pay.payUrl.Split('/')[-1])" | Out-Null
Start-Sleep -Seconds 5
$pointsAfter = (CallApi 'GET' '/api/auth/me' $ut).points
Check '支付后积分增加' ($pointsAfter -gt $pointsBefore)
$pointsLog = CallApi 'GET' '/api/auth/points/log?current=1&size=20' $ut
Check '积分明细记录' (@($pointsLog.records).Count -gt 0)

# 5. 发票
CallApi 'POST' '/api/order/invoice' $ut @{orderNo=$order.orderNo;type='PERSONAL';title='个人';email='user@demo.com'} | Out-Null
$invList = CallApi 'GET' '/api/order/invoice?current=1&size=20' $ut
$invId = @($invList.records)[0].id
CallApi 'POST' "/api/admin/invoices/$invId/issue" $at | Out-Null
$invList2 = CallApi 'GET' '/api/order/invoice?current=1&size=20' $ut
Check '发票申请并开具' (@($invList2.records | Where-Object { $_.id -eq $invId })[0].status -eq 'ISSUED')

# 6. 退款
$stockBefore = (CallApi 'GET' '/api/product/101').skus[0].stock
CallApi 'POST' '/api/order/refund' $ut @{orderNo=$order.orderNo;reason='测试退款'} | Out-Null
$refunds = CallApi 'GET' '/api/admin/refunds?current=1&size=20' $at
$refundId = @($refunds.records | Where-Object { $_.orderNo -eq $order.orderNo })[0].id
CallApi 'POST' "/api/admin/refunds/$refundId/audit" $at @{approve=$true;remark='同意退款'} | Out-Null
$refundAfter = CallApi 'GET' '/api/admin/refunds?current=1&size=20' $at
Check '退款审核通过' (@($refundAfter.records | Where-Object { $_.id -eq $refundId })[0].status -eq 'REFUNDED')
$orderAfter = CallApi 'GET' "/api/order/$($order.orderNo)" $ut
Check '退款后订单已退款' ($orderAfter.status -eq 'REFUNDED')
Start-Sleep -Seconds 4
$stockAfter = (CallApi 'GET' '/api/product/101').skus[0].stock
Check '退款后库存恢复' ($stockAfter -gt $stockBefore)
$pointsFinal = (CallApi 'GET' '/api/auth/me' $ut).points
Check '退款后积分扣减' ($pointsFinal -lt $pointsAfter)

Write-Host ''
Write-Host "交易闭环结果: 通过 $pass, 失败 $fail" -ForegroundColor Cyan
if ($fail -gt 0) { exit 1 }

