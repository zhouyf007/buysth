# 高并发与技术增强说明

## 1. 秒杀前置防护（已实现）

- 网关签名防刷：秒杀接口要求 `X-Timestamp`、`X-Nonce`、`X-Sign`，使用 FNV-1a 对密钥+路径+时间戳+随机数签名，时间戳 120 秒有效，nonce 在 Redis 中防重放
- 用户维度限流：同一用户每分钟最多发起 5 次秒杀请求，超限返回 429
- 验证码：秒杀前先获取 `GET /api/seckill/captcha`，提交时必须携带验证码，Redis 校验后一次性消费
- 原有 Redis+Lua 预扣库存、MQ 异步落单、死信队列超时关闭继续生效

## 2. 抢购结果异步化

秒杀接口返回后，订单由 MQ 异步创建；前端在抢购成功页自动轮询订单详情，订单出现后显示“去完成支付”，避免同步等待。

## 3. 多级缓存（已实现）

product-service 使用 Caffeine 本地缓存 + Redis 两级缓存：

- 商品详情、分类、热销榜单先查本地缓存，再查 Redis，最后查库
- 商品/分类/库存/销量变化时，清除本地缓存和 Redis，并发布 `cache.invalidate` 事件，多实例通过 MQ 同步失效

## 4. 链路追踪（已集成）

- 各服务引入 Micrometer Tracing + Brave + Zipkin Reporter，`deploy/docker-compose.infra.yml` 内置 Zipkin（9411）
- 访问 `http://localhost:9411` 查看跨服务调用链
- 各服务暴露 `/actuator/prometheus`，可接入 Prometheus + Grafana

## 5. 熔断降级（已集成）

- 引入 Spring Cloud Alibaba Sentinel，开启 `feign.sentinel.enabled=true`
- 商品服务 Feign 调用提供 `ProductClientFallback`，商品服务不可用时返回明确降级提示
- 生产可配置 Sentinel Dashboard 和热点参数规则，将秒杀接口的每分钟用户限流下沉到 Sentinel

## 6. 后续建议

- 秒杀接口签名可换成 HMAC-SHA256，并配合前端动态下发一次性签名
- Sentinel 规则建议通过 Dashboard 或 Nacos 配置持久化
- Zipkin 生产建议接入 Kafka 上报，避免直连上报阻塞业务线程

