# 分布式事务说明

## 当前实现：Saga / 事件补偿

当前订单、支付、库存、积分、优惠券、物流通过 RabbitMQ 事件串联，采用 Saga 风格的事务补偿：

- 下单锁定库存，超时/取消时通过 `order.cancelled` 事件释放库存
- 支付成功后通过 `order.paid` 事件给用户加积分、创建物流
- 退款通过 `order.refunded` 事件恢复库存、扣回积分、退回优惠券

补偿逻辑在 order-service、product-service、auth-service、seckill-service 内各自实现，保证最终一致。

## Seata AT 模式升级路径

AT 模式通过全局锁和 undo_log 实现自动回滚，代码侧只需在事务入口加 `@GlobalTransactional`。

启用步骤：

1. `deploy/docker-compose.infra.yml` 已内置 `seata` 服务（端口 8091），启动后用 SQL 在各业务库创建 undo_log 表：

```sql
CREATE TABLE IF NOT EXISTS undo_log (
  id BIGINT NOT NULL AUTO_INCREMENT,
  branch_id BIGINT NOT NULL,
  xid VARCHAR(100) NOT NULL,
  context VARCHAR(128) NOT NULL,
  rollback_info LONGBLOB NOT NULL,
  log_status INT NOT NULL,
  log_created DATETIME NOT NULL,
  log_modified DATETIME NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY ux_undo_log (xid, branch_id)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4;
```

2. 各服务引入 `spring-cloud-starter-alibaba-seata`，并配置：

```yaml
spring:
  cloud:
    alibaba:
      seata:
        tx-service-group: shop_tx_group
seata:
  registry:
    type: nacos
    nacos:
      server-addr: ${NACOS_ADDR:127.0.0.1:8848}
      application: seata-server
      group: SEATA_GROUP
  tx-service-group: shop_tx_group
```

3. 在 `OrderService.createOrder`、`createSeckillOrder` 等跨服务写入口加：

```java
@GlobalTransactional
public CreateOrderResult createOrder(...) { ... }
```

4. Seata Server 配置 `conf/registry.conf` 指向 Nacos，`conf/file.conf` 使用 `file` 或数据库事务日志存储。

## AT 与 Saga 差异

| 维度 | AT | Saga |
| --- | --- | --- |
| 实现方式 | 数据源代理 + undo_log 自动回滚 | 业务编写正向/补偿操作 |
| 隔离性 | 全局锁保证写隔离 | 无全局锁，靠业务补偿 |
| 代码侵入 | 低，只需注解 | 中，需实现每个子事务的补偿方法 |
| 适用场景 | 短事务、强一致性要求高 | 长事务、跨异构系统、允许最终一致 |

当前工程在演示环境保留 Saga 方案可独立运行；接入 Seata 后可将下单-锁库存-积分等短事务升级为 AT。

