<template>
  <div>
    <h2 class="page-title">{{ id ? '编辑活动' : '新增活动' }}</h2>
    <el-card>
      <el-form :model="form" label-width="100px">
        <el-row :gutter="16">
          <el-col :xs="24" :sm="12">
            <el-form-item label="活动名称" required><el-input v-model="form.name" /></el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12">
            <el-form-item label="活动类型">
              <el-radio-group v-model="form.type">
                <el-radio label="SECKILL">秒杀</el-radio>
                <el-radio label="PROMOTION">优惠</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12">
            <el-form-item label="开始时间" required>
              <el-date-picker v-model="form.startTime" type="datetime" style="width: 100%" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12">
            <el-form-item label="结束时间" required>
              <el-date-picker v-model="form.endTime" type="datetime" style="width: 100%" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12">
            <el-form-item label="状态">
              <el-select v-model="form.status" style="width: 100%">
                <el-option label="草稿" value="DRAFT" />
                <el-option label="上线" value="ONLINE" />
                <el-option label="结束" value="ENDED" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12">
            <el-form-item label="活动描述"><el-input v-model="form.description" /></el-form-item>
          </el-col>
          <template v-if="form.type === 'PROMOTION'">
            <el-col :xs="24" :sm="8">
              <el-form-item label="优惠码"><el-input v-model="form.promotionCode" placeholder="back-to-school" /></el-form-item>
            </el-col>
            <el-col :xs="24" :sm="8">
              <el-form-item label="折扣类型">
                <el-select v-model="form.discountType" style="width: 100%">
                  <el-option label="折扣(95折)" value="PERCENT" />
                  <el-option label="立减" value="FIXED" />
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :xs="24" :sm="8">
              <el-form-item label="折扣值">
                <el-input-number v-model="form.discountValue" :min="0" :precision="2" style="width: 100%" />
              </el-form-item>
            </el-col>
          </template>
        </el-row>

        <template v-if="form.type === 'SECKILL'">
          <el-divider>秒杀商品</el-divider>
          <el-table :data="form.products">
            <el-table-column label="商品规格" min-width="220">
              <template #default="{ row }">{{ skuLabel(row.skuId) }}</template>
            </el-table-column>
            <el-table-column label="SKU ID">
              <template #default="{ row }"><el-input-number v-model="row.skuId" :min="1" /></template>
            </el-table-column>
            <el-table-column label="秒杀价" width="160">
              <template #default="{ row }"><el-input-number v-model="row.seckillPrice" :min="0" :precision="2" /></template>
            </el-table-column>
            <el-table-column label="秒杀库存" width="160">
              <template #default="{ row }"><el-input-number v-model="row.seckillStock" :min="0" /></template>
            </el-table-column>
            <el-table-column label="限购" width="140">
              <template #default="{ row }"><el-input-number v-model="row.limitPerUser" :min="1" /></template>
            </el-table-column>
            <el-table-column label="操作" width="90">
              <template #default="{ $index }">
                <el-button link type="danger" @click="form.products.splice($index, 1)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="sku-actions">
            <el-button type="primary" plain @click="openPicker">从商品库选择规格</el-button>
            <el-button @click="form.products.push({ skuId: 201, seckillPrice: 0, seckillStock: 0, limitPerUser: 1, status: 1 })">
              添加秒杀商品
            </el-button>
          </div>
        </template>

        <div class="form-actions">
          <el-button @click="$router.back()">返回</el-button>
          <el-button type="primary" :loading="saving" @click="save">保存</el-button>
        </div>
      </el-form>
    </el-card>

    <el-dialog v-model="pickerVisible" title="从商品库选择规格" width="860px" top="6vh">
      <div class="picker-toolbar">
        <el-input v-model="pickerKeyword" placeholder="按商品名称搜索" clearable style="width: 260px" @keyup.enter="loadPicker(1)" />
        <el-button type="primary" @click="loadPicker(1)">查询</el-button>
      </div>
      <el-table
        ref="pickerTableRef"
        :data="skuRows"
        row-key="id"
        v-loading="pickerLoading"
        max-height="420"
        @selection-change="onPick"
      >
        <el-table-column type="selection" width="44" />
        <el-table-column label="商品" min-width="240">
          <template #default="{ row }">
            <div class="sku-cell">
              <img :src="row.image || row.mainImage" class="thumb" />
              <div>
                <div class="sku-name">{{ row.productName }}</div>
                <div class="muted">{{ row.specName }}：{{ row.specValue }}</div>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="SKU ID" prop="id" width="90" />
        <el-table-column label="售价" width="100">
          <template #default="{ row }">¥{{ row.price }}</template>
        </el-table-column>
        <el-table-column label="库存" prop="stock" width="80" />
      </el-table>
      <div class="pager">
        <el-pagination
          layout="total, prev, pager, next"
          :total="pickerTotal"
          :page-size="pickerSize"
          :current-page="pickerCurrent"
          @current-change="loadPicker"
        />
      </div>
      <template #footer>
        <el-button @click="pickerVisible = false">取消</el-button>
        <el-button type="primary" @click="confirmPicker">添加选中规格</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { activityApi, productApi } from '../api'

const route = useRoute()
const router = useRouter()
const id = route.params.id
const saving = ref(false)
const pickerVisible = ref(false)
const pickerLoading = ref(false)
const pickerKeyword = ref('')
const pickerRecords = ref([])
const pickerTotal = ref(0)
const pickerCurrent = ref(1)
const pickerSize = 6
const pickerSelected = ref([])
const pickerTableRef = ref()
const skuInfoMap = reactive({})
const form = reactive({
  name: '', type: 'SECKILL', startTime: null, endTime: null, status: 'DRAFT',
  description: '', promotionCode: '', discountType: 'PERCENT', discountValue: 95,
  products: []
})

const skuRows = computed(() => pickerRecords.value.flatMap(p =>
  (p.skus || []).map(s => ({ ...s, productName: p.name, mainImage: p.mainImage }))
))

const skuLabel = skuId => {
  const info = skuInfoMap[skuId]
  return info ? `${info.productName} ${info.spec}` : `SKU ${skuId}`
}

const loadPicker = async (page = 1) => {
  pickerCurrent.value = page || 1
  pickerLoading.value = true
  try {
    const data = await productApi.page({
      current: pickerCurrent.value,
      size: pickerSize,
      keyword: pickerKeyword.value || undefined
    })
    pickerRecords.value = data.records || []
    pickerTotal.value = data.total || 0
  } finally {
    pickerLoading.value = false
  }
}

const openPicker = () => {
  pickerSelected.value = []
  pickerKeyword.value = ''
  pickerVisible.value = true
  loadPicker(1)
}

const onPick = rows => {
  pickerSelected.value = rows
}

const confirmPicker = () => {
  if (!pickerSelected.value.length) {
    ElMessage.warning('请先勾选商品规格')
    return
  }
  const existing = new Set(form.products.map(p => p.skuId))
  let added = 0
  pickerSelected.value.forEach(s => {
    if (existing.has(s.id)) return
    existing.add(s.id)
    skuInfoMap[s.id] = { productName: s.productName, spec: `${s.specName}：${s.specValue}` }
    form.products.push({ skuId: s.id, seckillPrice: 0, seckillStock: 0, limitPerUser: 1, status: 1 })
    added++
  })
  pickerVisible.value = false
  ElMessage.success(added ? `已添加 ${added} 个商品规格` : '所选规格已在列表中')
}

const save = async () => {
  if (!form.name || !form.startTime || !form.endTime) {
    ElMessage.warning('请填写活动名称和起止时间')
    return
  }
  saving.value = true
  try {
    const payload = {
      ...form,
      startTime: new Date(form.startTime).toLocaleString('sv-SE').replace('T', ' '),
      endTime: new Date(form.endTime).toLocaleString('sv-SE').replace('T', ' '),
      products: form.type === 'SECKILL' ? form.products : []
    }
    if (id) {
      await activityApi.update(id, payload)
    } else {
      await activityApi.create(payload)
    }
    ElMessage.success('保存成功')
    router.push('/admin/activities')
  } finally {
    saving.value = false
  }
}

onMounted(async () => {
  if (id) {
    const a = await activityApi.detail(id)
    Object.assign(form, {
      name: a.name, type: a.type, startTime: a.startTime, endTime: a.endTime, status: a.status,
      description: a.description, promotionCode: a.promotionCode || '',
      discountType: a.discountType || 'PERCENT', discountValue: Number(a.discountValue || 95),
      products: (a.products || []).map(p => ({
        skuId: p.skuId, seckillPrice: Number(p.seckillPrice),
        seckillStock: p.seckillStock, limitPerUser: p.limitPerUser, status: 1
      }))
    })
  }
})
</script>

<style scoped>
.sku-actions {
  display: flex;
  gap: 10px;
  margin-top: 10px;
}

.picker-toolbar {
  display: flex;
  gap: 12px;
  align-items: center;
  margin-bottom: 14px;
}

.sku-cell {
  display: flex;
  align-items: center;
  gap: 10px;
}

.sku-name {
  font-weight: 600;
}

.muted {
  color: #888;
  font-size: 12px;
}

.thumb {
  width: 48px;
  height: 48px;
  object-fit: cover;
  border-radius: 6px;
  background: #fafafa;
}

.form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 20px;
}
</style>
