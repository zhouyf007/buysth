<template>
  <div>
    <h2 class="page-title">优惠券管理</h2>
    <div class="table-toolbar">
      <el-input v-model="query.keyword" placeholder="优惠券名称" clearable style="width: 220px" @keyup.enter="load(1)" />
      <el-button type="primary" @click="load(1)">查询</el-button>
      <el-button type="success" @click="openDialog()">新增优惠券</el-button>
    </div>
    <el-card>
      <el-table :data="records" v-loading="loading">
        <el-table-column prop="id" label="ID" width="80" />
        <el-table-column prop="name" label="名称" min-width="160" />
        <el-table-column label="类型" width="90">
          <template #default="{ row }">
            <el-tag :type="row.type === 'FIXED' ? '' : 'warning'">{{ row.type === 'FIXED' ? '满减' : '折扣' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="门槛/面额" min-width="150">
          <template #default="{ row }">
            满 ¥{{ row.threshold }} 减 ¥{{ row.discountValue }}
          </template>
        </el-table-column>
        <el-table-column label="库存" width="120">
          <template #default="{ row }">{{ row.receivedCount }} / {{ row.total }}</template>
        </el-table-column>
        <el-table-column label="有效期" min-width="220">
          <template #default="{ row }">{{ row.startTime?.slice(0, 16).replace('T', ' ') }} ~ {{ row.endTime?.slice(0, 16).replace('T', ' ') }}</template>
        </el-table-column>
        <el-table-column label="状态" width="90">
          <template #default="{ row }">
            <el-tag :type="row.status === 1 ? 'success' : 'info'">{{ row.status === 1 ? '启用' : '停用' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right">
          <template #default="{ row }">
            <el-button link type="primary" @click="openDialog(row)">编辑</el-button>
            <el-button link :type="row.status === 1 ? 'warning' : 'success'" @click="toggle(row)">
              {{ row.status === 1 ? '停用' : '启用' }}
            </el-button>
            <el-popconfirm title="确认删除该优惠券？" @confirm="remove(row)">
              <template #reference>
                <el-button link type="danger">删除</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
      <div class="pager">
        <el-pagination layout="total, prev, pager, next" :total="total" :page-size="query.size" :current-page="query.current" @current-change="load" />
      </div>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="form.id ? '编辑优惠券' : '新增优惠券'" width="560px">
      <el-form :model="form" label-width="100px">
        <el-form-item label="名称"><el-input v-model="form.name" /></el-form-item>
        <el-form-item label="类型">
          <el-radio-group v-model="form.type">
            <el-radio label="FIXED">满减</el-radio>
            <el-radio label="PERCENT">折扣</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="使用门槛">
          <el-input-number v-model="form.threshold" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="面额/折扣">
          <el-input-number v-model="form.discountValue" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="发放总量">
          <el-input-number v-model="form.total" :min="0" />
        </el-form-item>
        <el-form-item label="开始时间">
          <el-date-picker v-model="form.startTime" type="datetime" style="width: 100%" />
        </el-form-item>
        <el-form-item label="结束时间">
          <el-date-picker v-model="form.endTime" type="datetime" style="width: 100%" />
        </el-form-item>
        <el-form-item label="状态">
          <el-switch v-model="form.status" :active-value="1" :inactive-value="0" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { couponApi } from '../api'

const records = ref([])
const total = ref(0)
const loading = ref(false)
const dialogVisible = ref(false)
const query = reactive({ current: 1, size: 10, keyword: '' })
const form = reactive({ id: null, name: '', type: 'FIXED', threshold: 0, discountValue: 0, total: 0, startTime: null, endTime: null, status: 1 })

const load = async page => {
  query.current = page || 1
  loading.value = true
  try {
    const data = await couponApi.page({ current: query.current, size: query.size, keyword: query.keyword || undefined })
    records.value = data.records
    total.value = data.total
  } finally {
    loading.value = false
  }
}

const openDialog = row => {
  Object.assign(form, row ? { ...row } : { id: null, name: '', type: 'FIXED', threshold: 0, discountValue: 0, total: 0, startTime: null, endTime: null, status: 1 })
  dialogVisible.value = true
}

const save = async () => {
  const payload = { ...form }
  payload.startTime = form.startTime ? new Date(form.startTime).toISOString().slice(0, 19) : null
  payload.endTime = form.endTime ? new Date(form.endTime).toISOString().slice(0, 19) : null
  if (form.id) {
    await couponApi.update(form.id, payload)
  } else {
    await couponApi.create(payload)
  }
  ElMessage.success('保存成功')
  dialogVisible.value = false
  load(query.current)
}

const toggle = async row => {
  await couponApi.status(row.id, row.status === 1 ? 0 : 1)
  ElMessage.success('状态已更新')
  load(query.current)
}

const remove = async row => {
  await couponApi.remove(row.id)
  ElMessage.success('删除成功')
  load(query.current)
}

onMounted(() => load(1))
</script>
