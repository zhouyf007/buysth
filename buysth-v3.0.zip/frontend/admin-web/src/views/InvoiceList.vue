<template>
  <div>
    <h2 class="page-title">发票管理</h2>
    <div class="table-toolbar">
      <el-input v-model="query.keyword" placeholder="订单号/发票号" clearable style="width: 220px" @keyup.enter="load(1)" />
      <el-select v-model="query.status" placeholder="全部状态" clearable style="width: 140px">
        <el-option label="待开具" value="PENDING" />
        <el-option label="已开具" value="ISSUED" />
      </el-select>
      <el-button type="primary" @click="load(1)">查询</el-button>
    </div>
    <el-card>
      <el-table :data="records" v-loading="loading">
        <el-table-column prop="orderNo" label="订单号" min-width="190" />
        <el-table-column prop="userId" label="用户ID" width="110" />
        <el-table-column prop="type" label="类型" width="90" />
        <el-table-column prop="title" label="抬头" min-width="140" />
        <el-table-column prop="taxNo" label="税号" min-width="160" />
        <el-table-column prop="email" label="邮箱" min-width="160" />
        <el-table-column prop="invoiceNo" label="发票号" min-width="180" />
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === 'ISSUED' ? 'success' : 'warning'">{{ row.status === 'ISSUED' ? '已开具' : '待开具' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="110" fixed="right">
          <template #default="{ row }">
            <el-button v-if="row.status === 'PENDING'" link type="primary" @click="issue(row)">开具</el-button>
            <el-popconfirm title="确认删除该发票记录？" @confirm="remove(row)">
              <template #reference>
                <el-button link type="danger">删除</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
      <div class="pager">
        <el-pagination layout="total, prev, pager, next" :total="total" :page-size="query.size" :current-page="query.current" @current-change="load" />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { invoiceApi } from '../api'

const records = ref([])
const total = ref(0)
const loading = ref(false)
const query = reactive({ current: 1, size: 10, keyword: '', status: '' })

const load = async page => {
  query.current = page || 1
  loading.value = true
  try {
    const data = await invoiceApi.page({
      current: query.current, size: query.size,
      keyword: query.keyword || undefined,
      status: query.status || undefined
    })
    records.value = data.records
    total.value = data.total
  } finally {
    loading.value = false
  }
}

const issue = async row => {
  await invoiceApi.issue(row.id)
  ElMessage.success('发票已开具')
  load(query.current)
}

const remove = async row => {
  await invoiceApi.remove(row.id)
  ElMessage.success('发票记录已删除')
  load(query.current)
}

onMounted(() => load(1))
</script>
