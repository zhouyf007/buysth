<template>
  <div>
    <h2 class="page-title">退款管理</h2>
    <div class="table-toolbar">
      <el-input v-model="query.keyword" placeholder="订单号/退款单号" clearable style="width: 220px" @keyup.enter="load(1)" />
      <el-select v-model="query.status" placeholder="全部状态" clearable style="width: 140px">
        <el-option label="待审核" value="PENDING" />
        <el-option label="已退款" value="REFUNDED" />
        <el-option label="已拒绝" value="REJECTED" />
      </el-select>
      <el-button type="primary" @click="load(1)">查询</el-button>
    </div>
    <el-card>
      <el-table :data="records" v-loading="loading">
        <el-table-column prop="refundNo" label="退款单号" min-width="190" />
        <el-table-column prop="orderNo" label="订单号" min-width="190" />
        <el-table-column prop="userId" label="用户ID" width="110" />
        <el-table-column label="金额" width="110">
          <template #default="{ row }">¥{{ row.amount }}</template>
        </el-table-column>
        <el-table-column prop="reason" label="原因" min-width="180" show-overflow-tooltip />
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="row.status === 'REFUNDED' ? 'success' : row.status === 'PENDING' ? 'warning' : 'info'">
              {{ row.status === 'PENDING' ? '待审核' : row.status === 'REFUNDED' ? '已退款' : '已拒绝' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <template v-if="row.status === 'PENDING'">
              <el-button link type="success" @click="audit(row, true)">通过</el-button>
              <el-button link type="danger" @click="audit(row, false)">拒绝</el-button>
            </template>
            <el-popconfirm title="确认删除该退款记录？" @confirm="remove(row)">
              <template #reference>
                <el-button link type="danger">删除</el-button>
              </template>
            </el-popconfirm>
          </template>
        </el-table-column>
      </el-table>
      <div class="pager">
        <el-pagination layout="total, prev, pager, next" :total="total" :page-size="query.size" :current-page="query.current" @current-change="load" />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { refundApi } from '../api'

const records = ref([])
const total = ref(0)
const loading = ref(false)
const query = reactive({ current: 1, size: 10, keyword: '', status: '' })

const load = async page => {
  query.current = page || 1
  loading.value = true
  try {
    const data = await refundApi.page({
      current: query.current, size: query.size,
      keyword: query.keyword || undefined,
      status: query.status || undefined
    })
    records.value = data.records
    total.value = data.total
  } finally {
    loading.value = false
  }
}

const audit = async (row, approve) => {
  let remark = ''
  if (!approve) {
    try {
      const res = await ElMessageBox.prompt('请输入拒绝原因', '拒绝退款')
      remark = res.value
    } catch (e) {
      return
    }
  }
  await refundApi.audit(row.id, approve, remark)
  ElMessage.success(approve ? '退款已通过' : '退款已拒绝')
  load(query.current)
}

const remove = async row => {
  await refundApi.remove(row.id)
  ElMessage.success('退款记录已删除')
  load(query.current)
}

onMounted(() => load(1))
</script>
