import http from './http'

export const authApi = {
  register: data => http.post('/api/auth/register', data),
  login: data => http.post('/api/auth/login', data),
  me: () => http.get('/api/auth/me'),
  updateProfile: data => http.put('/api/auth/profile', data),
  changePassword: data => http.put('/api/auth/password', data),
  uploadAvatar: form => http.post('/api/auth/avatar/upload', form),
  pointsLog: params => http.get('/api/auth/points/log', { params }),
  logout: refreshToken => http.post('/api/auth/logout', { refreshToken })
}

export const productApi = {
  categories: () => http.get('/api/product/categories'),
  list: params => http.get('/api/product/list', { params }),
  detail: id => http.get(`/api/product/${id}`),
  hot: () => http.get('/api/product/hot'),
  reviews: (id, params) => http.get(`/api/product/${id}/reviews`, { params }),
  addReview: (id, data) => http.post(`/api/product/${id}/reviews`, data)
}

export const orderApi = {
  cart: () => http.get('/api/order/cart'),
  addCart: data => http.post('/api/order/cart', data),
  updateCart: (id, data) => http.put(`/api/order/cart/${id}`, data),
  deleteCart: id => http.delete(`/api/order/cart/${id}`),
  create: data => http.post('/api/order/create', data),
  list: params => http.get('/api/order/list', { params }),
  deleted: params => http.get('/api/order/deleted', { params }),
  detail: orderNo => http.get(`/api/order/${orderNo}`),
  cancel: orderNo => http.post(`/api/order/cancel/${orderNo}`),
  confirm: orderNo => http.post(`/api/order/confirm/${orderNo}`),
  address: (orderNo, data) => http.post(`/api/order/${orderNo}/address`, data),
  deleteOrder: orderNo => http.delete(`/api/order/${orderNo}`),
  restoreOrder: orderNo => http.post(`/api/order/${orderNo}/restore`),
  promotion: (orderNo, code) => http.post(`/api/order/${orderNo}/promotion`, { promotionCode: code }),
  previewPromotion: data => http.post('/api/order/promotion/preview', data)
}

export const addressApi = {
  list: () => http.get('/api/order/address'),
  save: data => http.post('/api/order/address', data),
  update: (id, data) => http.put(`/api/order/address/${id}`, data),
  remove: id => http.delete(`/api/order/address/${id}`),
  setDefault: id => http.put(`/api/order/address/${id}/default`)
}

export const couponApi = {
  list: params => http.get('/api/seckill/coupons', { params }),
  my: () => http.get('/api/seckill/coupons/my'),
  receive: id => http.post(`/api/seckill/coupons/${id}/receive`)
}

export const refundApi = {
  apply: data => http.post('/api/order/refund', data),
  list: params => http.get('/api/order/refund', { params })
}

export const invoiceApi = {
  apply: data => http.post('/api/order/invoice', data),
  list: params => http.get('/api/order/invoice', { params })
}

export const payApi = {
  create: orderNo => http.post('/api/pay/create', { orderNo }),
  status: orderNo => http.get(`/api/pay/status/${orderNo}`)
}

export const seckillApi = {
    activities: params => http.get('/api/seckill/activities', { params }),
    detail: id => http.get(`/api/seckill/activities/${id}`),
    captcha: () => http.get('/api/seckill/captcha'),
    myProducts: () => http.get('/api/seckill/my-products'),
    buy: async (activityId, productId, data) => {
    const path = `/api/seckill/${activityId}/products/${productId}`
    const headers = await buildSignHeaders(path)
    return http.post(path, data, { headers })
  }
}

export const logisticsApi = {
  track: orderNo => http.get(`/api/logistics/track/${orderNo}`)
}

export const notifyApi = {
  announcements: () => http.get('/api/notify/announcements'),
  messages: params => http.get('/api/notify/messages', { params }),
  unreadCount: () => http.get('/api/notify/messages/unread-count'),
  markRead: id => http.post(`/api/notify/messages/${id}/read`),
  deleteMessage: id => http.delete(`/api/notify/messages/${id}`),
  batchDelete: ids => http.post('/api/notify/messages/batch-delete', { ids })
}

const buildSignHeaders = async path => {
  const timestamp = String(Math.floor(Date.now() / 1000))
  const nonce = Math.random().toString(36).slice(2) + Date.now().toString(36)
  const secret = 'shop-sign-secret-2026'
  return {
    'X-Timestamp': timestamp,
    'X-Nonce': nonce,
    'X-Sign': await sha256(secret + path + timestamp + nonce)
  }
}

const sha256 = async str => {
  const data = new TextEncoder().encode(str)
  const buf = await crypto.subtle.digest('SHA-256', data)
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('')
}
