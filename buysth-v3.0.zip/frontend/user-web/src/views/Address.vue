<template>
  <div class="container page">
    <h1 class="page-title">收货地址</h1>
    <div class="toolbar">
      <button class="btn btn-primary" @click="openDialog()">新增地址</button>
    </div>
    <div v-if="items.length" class="address-list">
      <div v-for="a in items" :key="a.id" class="panel address-card">
        <div class="address-main">
          <strong>{{ a.receiverName }} {{ a.receiverPhone }}</strong>
          <p>{{ a.receiverAddress }}</p>
          <span v-if="a.isDefault === 1" class="tag">默认</span>
        </div>
        <div class="address-actions">
          <button v-if="a.isDefault !== 1" class="link-btn" @click="setDefault(a)">设为默认</button>
          <button class="link-btn" @click="openDialog(a)">编辑</button>
          <button class="link-btn danger" @click="remove(a)">删除</button>
        </div>
      </div>
    </div>
    <div v-else class="panel empty">还没有收货地址</div>
    <p class="error-text">{{ error }}</p>

    <div v-if="dialogVisible" class="dialog-mask" @click.self="dialogVisible = false">
      <div class="panel dialog-card">
        <h3>{{ form.id ? '编辑地址' : '新增地址' }}</h3>
        <label>收货人<input v-model="form.receiverName" class="input" /></label>
        <label>手机号<input v-model="form.receiverPhone" class="input" /></label>
        <label>详细地址<input v-model="form.receiverAddress" class="input" /></label>
        <label class="check"><input type="checkbox" v-model="form.isDefault" /> 设为默认地址</label>
        <div class="dialog-actions">
          <button class="btn btn-ghost" @click="dialogVisible = false">取消</button>
          <button class="btn btn-primary" @click="save">保存</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { addressApi } from '../api'

const items = ref([])
const error = ref('')
const dialogVisible = ref(false)
const form = reactive({ id: null, receiverName: '', receiverPhone: '', receiverAddress: '', isDefault: false })

const load = async () => {
  error.value = ''
  items.value = await addressApi.list()
}

const openDialog = row => {
  Object.assign(form, row
    ? { id: row.id, receiverName: row.receiverName, receiverPhone: row.receiverPhone, receiverAddress: row.receiverAddress, isDefault: row.isDefault === 1 }
    : { id: null, receiverName: '', receiverPhone: '', receiverAddress: '', isDefault: false })
  dialogVisible.value = true
}

const save = async () => {
  error.value = ''
  if (!form.receiverName || !/^1[3-9]\d{9}$/.test(form.receiverPhone) || !form.receiverAddress) {
    error.value = '请填写完整信息，手机号需为11位'
    return
  }
  const payload = { ...form, isDefault: form.isDefault ? 1 : 0 }
  if (form.id) {
    await addressApi.update(form.id, payload)
  } else {
    await addressApi.save(payload)
  }
  dialogVisible.value = false
  load()
}

const setDefault = async item => {
  await addressApi.setDefault(item.id)
  load()
}

const remove = async item => {
  if (!window.confirm('确认删除该地址？')) return
  await addressApi.remove(item.id)
  load()
}

onMounted(load)
</script>

<style scoped>
.page-title { margin: 0 0 18px; font-size: 22px; }
.toolbar { margin-bottom: 14px; }
.address-list { display: flex; flex-direction: column; gap: 12px; }
.address-card { display: flex; justify-content: space-between; align-items: center; padding: 16px 18px; }
.address-main p { margin: 6px 0 0; color: var(--muted); }
.tag { display: inline-block; margin-top: 8px; background: #fff2ec; color: var(--primary); border-radius: 4px; padding: 2px 8px; font-size: 12px; }
.address-actions { display: flex; gap: 10px; }
.link-btn { border: 0; background: transparent; color: var(--primary); cursor: pointer; font-size: 13px; }
.link-btn.danger { color: #d33; }
.dialog-mask { position: fixed; inset: 0; background: rgba(31,35,40,.45); display: flex; align-items: center; justify-content: center; z-index: 30; }
.dialog-card { width: 420px; padding: 24px; display: flex; flex-direction: column; gap: 12px; }
.dialog-card h3 { margin: 0; }
.dialog-card label { display: flex; flex-direction: column; gap: 6px; font-size: 13px; color: var(--muted); }
.dialog-card .check { flex-direction: row; align-items: center; }
.dialog-actions { display: flex; justify-content: flex-end; gap: 10px; }
</style>

