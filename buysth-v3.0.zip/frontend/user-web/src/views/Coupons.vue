<template>
  <div class="container page">
    <h1 class="page-title">领券中心</h1>
    <p v-if="notice" class="notice-text">{{ notice }}</p>
    <p class="error-text">{{ error }}</p>
    <div v-if="coupons.length" class="coupon-list">
      <div v-for="c in coupons" :key="c.id" class="panel coupon-card">
        <div class="coupon-info">
          <strong>{{ c.name }}</strong>
          <p class="muted">
            {{ c.type === 'FIXED' ? `满 ¥${c.threshold} 减 ¥${c.discountValue}` : `${c.discountValue} 折优惠` }}
          </p>
          <p class="muted">{{ c.startTime?.slice(0, 10) }} 至 {{ c.endTime?.slice(0, 10) }}</p>
        </div>
        <button class="btn btn-primary" :disabled="c.received || c.receivedCount >= c.total" @click="receive(c)">
          {{ c.received ? '已领取' : '立即领取' }}
        </button>
      </div>
    </div>
    <div v-else class="panel empty">暂无可用优惠券</div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { couponApi } from '../api'

const coupons = ref([])
const error = ref('')
const notice = ref('')

const load = async () => {
  const data = await couponApi.list({ current: 1, size: 50 })
  coupons.value = data.records
}

const receive = async c => {
  error.value = ''
  notice.value = ''
  try {
    await couponApi.receive(c.id)
    notice.value = `领取成功：${c.name}`
    c.received = true
    c.receivedCount = (c.receivedCount || 0) + 1
    await load()
  } catch (e) {
    error.value = e.message
  }
}

onMounted(load)
</script>

<style scoped>
.page-title { margin: 0 0 18px; font-size: 22px; }
.coupon-list { display: flex; flex-direction: column; gap: 12px; }
.coupon-card { display: flex; justify-content: space-between; align-items: center; padding: 16px 18px; border-left: 4px solid var(--primary); }
.coupon-info strong { font-size: 16px; }
.coupon-info p { margin: 6px 0 0; font-size: 13px; }
.notice-text { color: #16a34a; font-size: 14px; margin: 0 0 12px; }
</style>
