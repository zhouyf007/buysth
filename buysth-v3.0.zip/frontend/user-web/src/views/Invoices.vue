<template>
  <div class="container page">
    <h1 class="page-title">我的发票</h1>
    <div v-if="records.length" class="invoice-list">
      <div v-for="r in records" :key="r.id" class="panel invoice-card">
        <div>
          <strong>{{ r.orderNo }}</strong>
          <p class="muted">{{ r.type === 'COMPANY' ? `${r.title} (${r.taxNo})` : '个人发票' }}</p>
        </div>
        <span class="status-tag">{{ r.status === 'ISSUED' ? `已开具 ${r.invoiceNo}` : '待开具' }}</span>
      </div>
    </div>
    <div v-else class="panel empty">暂无发票</div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { invoiceApi } from '../api'

const records = ref([])

onMounted(async () => {
  const data = await invoiceApi.list({ current: 1, size: 20 })
  records.value = data.records
})
</script>

<style scoped>
.page-title { margin: 0 0 18px; font-size: 22px; }
.invoice-list { display: flex; flex-direction: column; gap: 12px; }
.invoice-card { display: flex; justify-content: space-between; align-items: center; padding: 16px 18px; }
.invoice-card p { margin: 6px 0 0; }
.status-tag { color: var(--primary); font-size: 13px; }
</style>

