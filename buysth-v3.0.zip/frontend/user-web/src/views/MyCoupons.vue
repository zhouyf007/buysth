<template>
  <div class="container page">
    <h1 class="page-title">我的优惠券</h1>
    <div v-if="coupons.length" class="coupon-list">
      <div v-for="c in coupons" :key="c.userCouponId" class="panel coupon-card">
        <div>
          <strong>{{ c.name }}</strong>
          <p class="muted">{{ c.type === 'FIXED' ? `满 ¥${c.threshold} 减 ¥${c.discountValue}` : `${c.discountValue} 折优惠` }}</p>
          <p class="muted">有效期至 {{ c.endTime?.slice(0, 10) }}</p>
        </div>
        <span class="status-tag" :class="c.status">{{ statusText[c.status] || c.status }}</span>
      </div>
    </div>
    <div v-else class="panel empty">暂无优惠券，去领券中心看看吧</div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { couponApi } from '../api'

const coupons = ref([])
const statusText = { UNUSED: '未使用', USED: '已使用', EXPIRED: '已过期' }

onMounted(async () => {
  coupons.value = await couponApi.my()
})
</script>

<style scoped>
.page-title { margin: 0 0 18px; font-size: 22px; }
.coupon-list { display: flex; flex-direction: column; gap: 12px; }
.coupon-card { display: flex; justify-content: space-between; align-items: center; padding: 16px 18px; }
.coupon-card p { margin: 6px 0 0; }
.status-tag { border-radius: 4px; padding: 4px 10px; font-size: 12px; }
.status-tag.UNUSED { background: #fff2ec; color: var(--primary); }
.status-tag.USED { background: #eef4ff; color: #2563eb; }
.status-tag.EXPIRED { background: #f3f4f6; color: var(--muted); }
</style>

