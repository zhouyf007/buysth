<template>
  <div class="container page">
    <h1 class="page-title">我的积分</h1>
    <div class="panel points-card">
      <div class="points-value">{{ auth.user?.points ?? 0 }}</div>
      <div class="muted">当前积分 · 会员等级 Lv.{{ auth.user?.level ?? 1 }}</div>
    </div>
    <h2 class="sub-title">积分明细</h2>
    <div v-if="logs.length" class="log-list">
      <div v-for="l in logs" :key="l.id" class="panel log-row">
        <div>
          <strong>{{ l.reason }}</strong>
          <p class="muted">{{ l.orderNo }} · {{ l.createTime?.replace('T', ' ') }}</p>
        </div>
        <span :class="l.changePoints >= 0 ? 'plus' : 'minus'">{{ l.changePoints >= 0 ? '+' : '' }}{{ l.changePoints }}</span>
      </div>
    </div>
    <div v-else class="panel empty">暂无积分明细</div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { authApi } from '../api'
import { useAuthStore } from '../stores/auth'

const auth = useAuthStore()
const logs = ref([])

onMounted(async () => {
  try {
    await auth.fetchMe()
  } catch (e) { /* ignore */ }
  const data = await authApi.pointsLog({ current: 1, size: 50 })
  logs.value = data.records
})
</script>

<style scoped>
.page-title { margin: 0 0 18px; font-size: 22px; }
.points-card { padding: 28px; text-align: center; }
.points-value { font-size: 44px; font-weight: 800; color: var(--primary); }
.sub-title { margin: 24px 0 12px; font-size: 18px; }
.log-list { display: flex; flex-direction: column; gap: 10px; }
.log-row { display: flex; justify-content: space-between; align-items: center; padding: 14px 16px; }
.log-row p { margin: 6px 0 0; }
.plus { color: #16a34a; font-weight: 700; }
.minus { color: #d33; font-weight: 700; }
</style>

