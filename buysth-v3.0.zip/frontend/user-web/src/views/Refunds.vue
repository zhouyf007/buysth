<template>
  <div class="container page">
    <h1 class="page-title">退款记录</h1>
    <div v-if="records.length" class="refund-list">
      <div v-for="r in records" :key="r.id" class="panel refund-card">
        <div>
          <strong>{{ r.orderNo }}</strong>
          <p class="muted">{{ r.reason }}</p>
          <p class="muted">{{ r.applyTime?.replace('T', ' ') }}</p>
        </div>
        <div class="right">
          <span class="price">¥{{ r.amount }}</span>
          <span class="status-tag">{{ statusText[r.status] || r.status }}</span>
        </div>
      </div>
    </div>
    <div v-else class="panel empty">暂无退款记录</div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { refundApi } from '../api'

const records = ref([])
const statusText = { PENDING: '待审核', REFUNDED: '已退款', REJECTED: '已拒绝' }

onMounted(async () => {
  const data = await refundApi.list({ current: 1, size: 20 })
  records.value = data.records
})
</script>

<style scoped>
.page-title { margin: 0 0 18px; font-size: 22px; }
.refund-list { display: flex; flex-direction: column; gap: 12px; }
.refund-card { display: flex; justify-content: space-between; align-items: center; padding: 16px 18px; }
.refund-card p { margin: 6px 0 0; }
.right { display: flex; flex-direction: column; align-items: flex-end; gap: 6px; }
.status-tag { color: var(--primary); font-size: 13px; }
</style>

