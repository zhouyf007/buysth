<template>
  <div class="container page">
    <div class="seckill-head">
      <div>
        <h1>{{ type === 'SECKILL' ? '限时秒杀' : '优惠活动' }}</h1>
        <p class="muted">{{ type === 'SECKILL' ? '限时限量，抢完即止' : '支付时输入活动优惠码即可享受折扣' }}</p>
      </div>
      <RouterLink v-if="type === 'PROMOTION'" to="/seckill" class="btn btn-ghost">查看秒杀</RouterLink>
      <RouterLink v-else to="/promotions" class="btn btn-ghost">查看优惠</RouterLink>
    </div>

    <div v-if="activities.length" class="activity-list">
      <div v-for="activity in activities" :key="activity.id" class="panel activity-card">
        <div class="activity-info">
          <span class="type-tag">{{ activity.type === 'SECKILL' ? '秒杀' : '优惠' }}</span>
          <h2>{{ activity.name }}</h2>
          <p>{{ activity.description }}</p>
          <div class="time-row">
            <span v-if="type === 'SECKILL'">{{ started(activity) ? '距结束' : '距开始' }}</span>
            <strong>{{ countdown(started(activity) ? activity.endTime : activity.startTime) }}</strong>
          </div>
          <span v-if="activity.type === 'PROMOTION' && activity.discountType === 'PERCENT'" class="promo-tip">
            优惠码：{{ activity.promotionCode }} · 享 {{ activity.discountValue }} 折
          </span>
          <span v-if="activity.type === 'PROMOTION' && activity.discountType === 'FIXED'" class="promo-tip">
            优惠码：{{ activity.promotionCode }} · 立减 ¥{{ activity.discountValue }}
          </span>
        </div>
        <div v-if="activity.products?.length" class="product-grid">
          <div v-for="p in activity.products" :key="p.id" class="seckill-product">
            <img :src="p.image" :alt="p.productName" />
            <div class="product-body">
              <strong>{{ p.productName }}</strong>
              <p v-if="p.skuSpec" class="muted">{{ p.skuSpec }}</p>
              <div class="price-row">
                <span class="price big">¥{{ p.seckillPrice }}</span>
                <span v-if="p.remainStock !== null" class="muted">剩余 {{ p.remainStock }}</span>
              </div>
              <div v-if="activity.type === 'SECKILL'" class="captcha-row">
                <span>{{ captchaQuestion }}</span>
                <input v-model="captchaAnswer" class="input small-input" placeholder="答案" />
              </div>
              <div class="buy-row">
                <button
                  v-if="activity.type === 'SECKILL'"
                  class="btn btn-primary buy-btn"
                  :disabled="purchasedIds.has(p.id) || !started(activity) || buyingId === p.id"
                  @click="buy(activity.id, p.id)"
                >{{ purchasedIds.has(p.id) ? '已抢购' : (!started(activity) ? '未开始' : (buyingId === p.id ? '抢购中' : '立即抢购')) }}</button>
                <span v-if="errorMap[p.id]" class="buy-error">{{ errorMap[p.id] }}</span>
              </div>
            </div>
          </div>
        </div>
        <p v-else-if="activity.type === 'SECKILL'" class="muted">秒杀商品配置中</p>
      </div>
    </div>
    <div v-if="type === 'PROMOTION' && promoProducts.length" class="panel activity-card">
      <div class="activity-info">
        <span class="type-tag">优惠商品</span>
        <h2>可享优惠的商品</h2>
        <p>加入购物车后在结算页输入活动优惠码，即可自动享受折扣。</p>
      </div>
      <div class="product-grid">
        <div v-for="p in promoProducts" :key="p.id" class="seckill-product">
          <RouterLink :to="`/products/${p.id}`">
            <img :src="p.mainImage" :alt="p.name" />
          </RouterLink>
          <div class="product-body">
            <RouterLink :to="`/products/${p.id}`" class="promo-link">
              <strong>{{ p.name }}</strong>
            </RouterLink>
            <p v-if="p.region" class="muted">{{ p.region }}</p>
            <div class="price-row">
              <span class="muted strike">¥{{ p.minPrice }}</span>
              <span class="price big">¥{{ discounted(p.minPrice) }}</span>
            </div>
            <div class="buy-row">
              <button class="btn btn-primary buy-btn" @click="buyPromo(p)">加入购物车</button>
              <span v-if="errorMap[p.id]" class="buy-error">{{ errorMap[p.id] }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-if="!activities.length && !(type === 'PROMOTION' && promoProducts.length)" class="panel empty">{{ type === 'SECKILL' ? '暂无秒杀活动' : '暂无优惠活动' }}</div>

    <div v-if="successDialogVisible" class="modal-mask" @click.self="successDialogVisible = false">
      <div class="modal-box">
        <h3 class="success-title">抢购成功</h3>
        <p class="muted">订单号：{{ successOrderNo }}</p>
        <p v-if="successPending" class="muted">订单正在异步创建，请稍候...</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" @click="successDialogVisible = false">关闭</button>
          <button class="btn btn-primary" :disabled="successPending" @click="goPay">去支付</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, reactive, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { orderApi, productApi, seckillApi } from '../api'
import { useAuthStore } from '../stores/auth'

const props = defineProps({ type: { type: String, default: 'SECKILL' } })
const router = useRouter()
const auth = useAuthStore()
const activities = ref([])
const promoProducts = ref([])
const buyingId = ref(null)
const purchasedIds = ref(new Set())
const successDialogVisible = ref(false)
const successPending = ref(false)
const successOrderNo = ref('')
const captchaId = ref('')
const captchaQuestion = ref('')
const captchaAnswer = ref('')
const errorMap = reactive({})
const now = ref(Date.now())

const filtered = computed(() => activities.value.filter(a => a.type === props.type))
const promoActivity = computed(() => activities.value.find(a => a.type === 'PROMOTION'))

let timer

const countdown = end => {
  const diff = new Date(end).getTime() - now.value
  if (diff <= 0) return '已结束'
  const h = Math.floor(diff / 3600000)
  const m = Math.floor(diff % 3600000 / 60000)
  const s = Math.floor(diff % 60000 / 1000)
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

const started = activity => new Date(activity.startTime).getTime() <= now.value

const buy = async (activityId, productId) => {
  errorMap[productId] = ''
  if (!auth.isLogin) {
    router.push('/login')
    return
  }
  buyingId.value = productId
  try {
    if (!captchaAnswer.value.trim()) {
      errorMap[productId] = '请输入验证码'
      return
    }
    const result = await seckillApi.buy(activityId, productId, {
      captchaId: captchaId.value,
      captchaAnswer: captchaAnswer.value
    })
    if (result.success) {
      delete errorMap[productId]
      successOrderNo.value = result.orderNo
      successPending.value = true
      successDialogVisible.value = true
      purchasedIds.value.add(productId)
      await waitOrder(result.orderNo)
      successPending.value = false
    } else {
      errorMap[productId] = result.message
    }
    loadCaptcha()
  } catch (e) {
    errorMap[productId] = e.message
    loadCaptcha()
  } finally {
    buyingId.value = null
    load()
  }
}

const goPay = () => {
  successDialogVisible.value = false
  router.push(`/orders/${successOrderNo.value}`)
}

const loadCaptcha = async () => {
  captchaAnswer.value = ''
  try {
    const data = await seckillApi.captcha()
    captchaId.value = data.captchaId
    captchaQuestion.value = data.question
  } catch (e) {
    captchaQuestion.value = '验证码获取失败'
  }
}

const waitOrder = async orderNo => {
  for (let i = 0; i < 15; i++) {
    await new Promise(r => setTimeout(r, 1000))
    try {
      const order = await orderApi.detail(orderNo)
      if (order && order.orderNo) {
        return
      }
    } catch (e) {
      // 订单尚未创建
    }
  }
}

const discounted = price => {
  const a = promoActivity.value
  const n = Number(price || 0)
  if (!a || !n) return n
  if (a.discountType === 'PERCENT') {
    return (n * Number(a.discountValue) / 100).toFixed(2)
  }
  if (a.discountType === 'FIXED') {
    return Math.max(n - Number(a.discountValue), 0).toFixed(2)
  }
  return n.toFixed(2)
}

const buyPromo = async product => {
  if (!auth.isLogin) {
    router.push('/login')
    return
  }
  errorMap[product.id] = ''
  const sku = product.skus?.[0]
  if (!sku) {
    errorMap[product.id] = '该商品暂无可售规格'
    return
  }
  try {
    await orderApi.addCart({ skuId: sku.id, quantity: 1 })
    router.push('/cart')
  } catch (e) {
    errorMap[product.id] = e.message
  }
}

const load = async () => {
  const data = await seckillApi.activities({ current: 1, size: 20, type: props.type })
  activities.value = data.records
  if (props.type === 'PROMOTION') {
    try {
      promoProducts.value = await productApi.hot()
    } catch (e) {
      promoProducts.value = []
    }
  }
}

const loadPurchased = async () => {
  if (!auth.isLogin) return
  try {
    const ids = await seckillApi.myProducts()
    ids.forEach(id => purchasedIds.value.add(id))
  } catch (e) {
    // 未登录或接口暂不可用时忽略
  }
}

watch(() => props.type, () => {
  activities.value = []
  promoProducts.value = []
  for (const key of Object.keys(errorMap)) delete errorMap[key]
  load()
  if (props.type === 'SECKILL') {
    loadCaptcha()
    loadPurchased()
  }
})

onMounted(() => {
  load()
  if (props.type === 'SECKILL') {
    loadCaptcha()
    loadPurchased()
  }
  timer = setInterval(() => { now.value = Date.now() }, 1000)
})

onUnmounted(() => clearInterval(timer))
</script>

<style scoped>
.seckill-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.seckill-head h1 {
  margin: 0;
  font-size: 26px;
}

.activity-list {
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.activity-card {
  padding: 22px;
}

.type-tag {
  background: var(--primary);
  color: #fff;
  font-size: 12px;
  border-radius: 4px;
  padding: 3px 8px;
}

.activity-info h2 {
  margin: 10px 0 6px;
  font-size: 18px;
}

.activity-info p {
  color: var(--muted);
  margin: 0;
  font-size: 13px;
}

.time-row {
  display: flex;
  gap: 8px;
  align-items: center;
  margin-top: 12px;
  color: var(--muted);
  font-size: 13px;
}

.time-row strong {
  color: var(--primary);
  font-size: 18px;
}

.promo-tip {
  display: inline-block;
  margin-top: 10px;
  background: #fff7f2;
  color: var(--primary);
  border-radius: 6px;
  padding: 6px 10px;
  font-size: 13px;
}

.product-grid {
  display: flex;
  flex-direction: column;
  gap: 14px;
  margin-top: 18px;
}

.seckill-product {
  display: flex;
  align-items: center;
  gap: 18px;
  border: 1px solid var(--line);
  border-radius: var(--radius);
  padding: 12px;
  text-align: left;
}

.seckill-product img {
  width: 150px;
  height: 150px;
  flex: 0 0 150px;
  object-fit: cover;
  border-radius: 6px;
  background: #fafafa;
}

.product-body {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.seckill-product strong {
  display: block;
  font-size: 14px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.seckill-product p {
  margin: 0;
  font-size: 12px;
}

.price-row {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  margin: 8px 0;
}

.strike {
  text-decoration: line-through;
}

.promo-link {
  display: block;
  color: inherit;
}

.price.big {
  font-size: 20px;
}

.buy-btn {
  width: 180px;
}

.buy-row {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.buy-error {
  color: #e5484d;
  font-size: 12px;
}

.captcha-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 10px 0;
  font-size: 13px;
  color: var(--muted);
}

.small-input {
  width: 72px;
  padding: 6px 8px;
}

.modal-mask {
  position: fixed;
  inset: 0;
  z-index: 1000;
  background: rgba(15, 23, 42, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.modal-box {
  width: 100%;
  max-width: 420px;
  background: #fff;
  border-radius: 10px;
  padding: 26px;
  text-align: center;
  box-shadow: 0 18px 50px rgba(0, 0, 0, 0.2);
}

.success-title {
  color: var(--primary);
  margin: 0 0 10px;
}

.modal-actions {
  display: flex;
  justify-content: center;
  gap: 12px;
  margin-top: 20px;
}

@media (max-width: 760px) {
  .seckill-product {
    flex-wrap: wrap;
  }

  .seckill-product img {
    width: 110px;
    height: 110px;
    flex: 0 0 110px;
  }

  .buy-btn {
    width: 100%;
  }

  .buy-error {
    width: 100%;
  }
}
</style>
